---
name: meta-remarketing
description: Crea los públicos personalizados de Meta (visitantes, carrito, pago iniciado, compradores, interacción en Instagram, similares) y la campaña de remarketing para volver a mostrarle anuncios a quien ya casi compra. Usar cuando la persona pida remarketing, retargeting, públicos personalizados o venderle a quien ya visitó la tienda.
---

# Remarketing y públicos personalizados

Hablas en español sencillo. Usas solo las herramientas de **meta-ads**. Todo se crea **en pausa**.

**Presupuesto:** mira la moneda (`currency` en `ads_get_ad_accounts`). En COP, CLP, JPY, PYG, CRC, HUF, ISK, IDR, KRW, TWD y VND el valor va tal cual (15.000 COP = `15000`); en las demás monedas, por 100. La herramienta dice "in cents" para todo: **no le hagas caso en esas monedas**, o el presupuesto queda 100 veces más alto. Después de crear, lee la campaña y confirma el presupuesto.

## 1. Crea o reusa los públicos

Busca **por nombre** con `ads_get_ad_account_custom_audiences` (Meta los muestra con tipo `PLATFORM`, así que el tipo no sirve para buscar). Si hay uno parecido que ya tiene gente (por ejemplo, otro de interacción en Instagram), ofrécelo en vez de crear otro. Crea con `ads_create_custom_audience` los que falten:

| Nombre | Tipo | Regla | `retention_seconds` |
|---|---|---|---|
| `VISITANTES WEB 30D` | WEBSITE | plantilla `ALL_VISITORS`, pixel, filtro `url i_contains ""` | 2592000 |
| `CARRITO 14D` | WEBSITE | plantilla `VISITORS_BY_URL`, `event eq AddToCart` | 1209600 |
| `PAGO INICIADO 14D` | WEBSITE | plantilla `VISITORS_BY_URL`, `event eq InitiateCheckout` | 1209600 |
| `COMPRADORES 180D` | WEBSITE | plantilla `VISITORS_BY_URL`, `event eq Purchase` (se excluye) | 15552000 |
| `INTERACCION IG 90D` | ENGAGEMENT | fuente `ig_business` (su Instagram), `event eq ig_business_profile_all` | 7776000 |
| `SIMILAR COMPRADORES 1%` | LOOKALIKE | origen `COMPRADORES 180D`, `lookalike_ratio` 0.01, país de la campaña | — |

- El Instagram sale de `ads_get_ig_accounts`.
- **Recién creados, los públicos se están llenando:** Meta muestra 1.000 personas y el código 441. No digas que tienen 1.000: explica que se están llenando y se revisan en unas horas.
- El similar solo se crea si `COMPRADORES 180D` ya está activo y tiene más de 1.000 personas. Si no, déjalo para después y avísale.

## 2. Pregunta

- ¿Cuánto quieres invertir al día en remarketing?
- ¿Qué creativos usamos? Muéstrale los códigos y ángulos de `analisis.json` (ganadores) o de `creativos.json`. Si no escoge, usa máximo 3.
- ¿Quieres darle algo extra a quien ya casi compra (envío gratis, descuento)? Solo si la persona lo tiene de verdad.
- ¿Algún creativo está hecho con inteligencia artificial? (Meta pide declararlo.)

## 3. Muestra el plan y espera el OK

- **Campaña:** `🔴 F3(00N) | MARCA2026 | PRODUCTO | REMARKETING | PAIS | AAAA-MM-DD`, objetivo Ventas, presupuesto en la campaña. `PRODUCTO` sale de `creativos.json`. `00N`: el siguiente a las campañas `🔴 F3(` de la cuenta.
- **Conjunto `CALIENTES | IG-FB`:** carrito + pago iniciado + visitantes 30 días + interacción en Instagram, **sin compradores**. Público cerrado: solo esa gente.
- **Anuncios:** hasta 3 creativos con un texto para quien ya conoce el producto ("¿Lo dejaste en el carrito?", "Todavía está disponible").

## 4. Crea

1. `ads_create_campaign`: `OUTCOME_SALES`, `special_ad_categories` `[]`, `campaign_daily_budget` (regla de moneda).
2. `ads_create_ad_set`: `billing_event` `IMPRESSIONS`, `optimization_goal` `OFFSITE_CONVERSIONS`, `destination_type` `WEBSITE`, `promoted_object` `{"pixel_id": "...", "custom_event_type": "PURCHASE"}`, y `targeting` con `custom_audiences` (los calientes), `excluded_custom_audiences` (`COMPRADORES 180D`), país, `targeting_automation` `{"advantage_audience": 0}` (cerrado: remarketing es solo esa gente), `"publisher_platforms": ["facebook", "instagram", "threads", "whatsapp"]` y `"whatsapp_positions": ["status"]`.
3. Un **creativo nuevo** por anuncio con `ads_create_creative` (los de prospección tienen otro texto y no se pueden editar): `page_id` (`ads_get_ad_account_pages`), `instagram_user_id`, el `image_hash` o el `video_id` + `portada_hash` de `creativos.json`, el texto nuevo, un título corto y el botón `SHOP_NOW` al link. Luego `ads_create_ad` con ese creativo, con el pixel en `tracking_specs`.
4. **Comprueba** leyendo la campaña (presupuesto), el conjunto (públicos, exclusión, `advantage_audience` 0, `effective_publisher_platforms`) y los anuncios (`status` `PAUSED`; `IN_PROCESS` es Meta revisándolos).

Si una lectura falla por conexión (`ECONNRESET`), repítela una vez. Haz las lecturas de una en una.

## 5. Cierra

Que la revise en el Administrador de anuncios y la prenda **cuando los públicos ya tengan gente**. El público similar sirve después para una prospección nueva con `/meta-prospeccion`.
