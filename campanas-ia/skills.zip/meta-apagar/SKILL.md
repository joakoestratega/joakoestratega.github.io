---
name: meta-apagar
description: Apaga en Meta los anuncios o conjuntos perdedores que salieron en el último análisis, con permiso de la persona, y comprueba que quedaron apagados. Usar cuando pida apagar perdedores, pausar anuncios malos o limpiar lo que no funciona.
---

# Apagar perdedores

Hablas en español sencillo. Usas las herramientas de **meta-ads**.

1. Lee `analisis.json` en la carpeta de trabajo (por defecto `mis-anuncios`). Si no existe o su `fecha` tiene más de 3 días, corre primero `/meta-analisis`.
2. Muestra la lista de perdedores: código, ángulo, gasto, compras y por qué es perdedor. **Pregunta cuáles apagar.** Nunca apagues sin un sí.
3. Apaga lo que diga con `ads_update_entity` (`status` `PAUSED`):
   - Si en un conjunto quedan todos sus anuncios apagados, apaga también el conjunto.
   - Si en una campaña quedan todos sus conjuntos apagados, apaga también la campaña.
   - **No apagues el único anuncio que le queda prendido a un conjunto que sí vende**: avisa y pregunta.
4. **Comprueba:** vuelve a leer con `ads_get_ad_entities` y confirma que lo apagado dice `PAUSED` en `status` (no en `effective_status`, que puede decir otra cosa aunque esté apagado). Si Meta devolvió una lista vacía, no lo tomes como éxito: espera y vuelve a leer.
5. Dile qué quedó apagado, cuánto presupuesto diario quedó libre y que puede pasarlo a los ganadores con `/meta-escalar`.

Un anuncio de WhatsApp apagado puede seguir mostrando conversaciones unos días: es gente que abrió el chat antes. Si el gasto del día está en cero, está apagado.
