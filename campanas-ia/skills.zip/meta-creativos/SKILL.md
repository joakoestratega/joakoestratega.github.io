---
name: meta-creativos
description: Ordena los creativos (imágenes y videos) de una carpeta, los agrupa de a 3 por conjunto, les pone nombre y los sube a la cuenta publicitaria de Meta desde el PC. Usar cuando la persona quiera preparar, nombrar u organizar sus creativos o subirlos a Meta antes de crear una campaña.
---

# Preparar y subir creativos a Meta

Hablas siempre en español sencillo, como a alguien que nunca ha hecho esto. Usas las herramientas del conector **meta-ads**. Si no responden, le pides que escriba `/mcp`, entre a **meta-ads** y toque **Authenticate**.

## 1. Pregunta en un solo mensaje

- ¿En qué carpeta están los creativos? (por defecto: `mis-anuncios` en el escritorio)
- ¿Qué producto o marca son? (una palabra, para el nombre)
- Si tiene varias cuentas publicitarias (`ads_get_ad_accounts`), ¿en cuál trabajamos?
- Si la cuenta tiene varias páginas (`ads_get_ad_account_pages`), ¿con cuál salen los anuncios? Busca también su Instagram con `ads_get_ig_accounts`.

## 2. Mira cada creativo

Abre cada imagen y mira los videos (nombre, duración, peso). Acepta JPG, PNG, MP4 y MOV. Imágenes de hasta 30 MB y videos de hasta 100 MB; si uno pesa más, avisa y sáltalo.

Por cada creativo decide en pocas palabras **qué ángulo tiene** (de qué habla o qué muestra: antes y después, dolor, testimonio, oferta, producto en uso…). Si un creativo no tiene que ver con el producto que te dijo, avísale.

## 3. Agrúpalos de a 3

- Cada conjunto de la campaña lleva **máximo 3 creativos**. Junta los que tengan el mismo ángulo o se parezcan, para que el conjunto mida una sola idea.
- Grupos: `C01`, `C02`, `C03`… Si sobra un grupo de 1 o 2, queda así.
- Nombre de cada archivo: `C01-A1-angulo-corto.ext`, `C01-A2-…`, `C01-A3-…`, `C02-A1-…` (sin tildes ni espacios, en minúscula).

Muéstrale la tabla (grupo · archivo nuevo · ángulo · imagen o video) y **espera su OK**. Si quiere mover alguno de grupo, lo cambias.

## 4. Renombra y sube

Con el OK, renombra los archivos en la carpeta. Luego súbelos uno por uno a la cuenta:

1. Saca el tamaño exacto en bytes y el SHA-256 en minúscula del archivo (`stat -c %s` y `sha256sum`; en Mac `stat -f %z` y `shasum -a 256`).
2. Llama `ads_creative_upload_local_image` con `ad_account_id` (sin `act_`), `image_name` (el nombre del archivo), `mime_type` (`image/jpeg`, `image/png`, `video/mp4` o `video/quicktime`), `media_kind` (`image` o `video`), `file_size` y `image_sha256`.
3. Envía el archivo con curl a lo que devolvió. **Lleva todos estos encabezados**, si falta `X-Entity-Name` Meta lo rechaza con error 400:
   ```
   curl -sS -w "\nHTTP %{http_code}\n" -X POST "<upload_url>" -H "Authorization: <upload_authorization>" -H "offset: 0" -H "file_size: <bytes>" -H "X-Entity-Name: <nombre>" -H "X-Entity-Length: <bytes>" -H "X-Entity-Type: <mime>" -H "Content-Type: <mime>" --data-binary @"<ruta del archivo>"
   ```
   Debe responder `HTTP 200` con un `completion_token`. Copia la `upload_authorization` completa: es larga y no se puede cortar. En Windows usa `curl.exe` si `curl` no responde igual.
4. Con el `completion_token` de la respuesta llama `ads_finalize_local_ad_image_upload`. Te devuelve el `hash` (imagen) o el `video_id` (video). La autorización sirve una sola vez y vence en ~30 minutos: si vence, empieza ese archivo de nuevo.
5. **Videos:** espera con `ads_get_ad_videos` hasta que el estado sea `ready`. Cada video necesita una **portada** de buena calidad (la miniatura que da Meta mide 160 × 160 y se ve borrosa):
   - Si hay una imagen con el mismo nombre del video (por ejemplo `video-a-portada.jpg`), esa es la portada.
   - Si no, saca un cuadro del segundo 1 del video con `ffmpeg -ss 1 -i video.mp4 -frames:v 1 video-portada.jpg` si ffmpeg está instalado.
   - Si no hay ffmpeg, pídele a la persona una imagen de portada.
   Sube la portada igual que las imágenes y guarda su hash como `portada_hash`.

## 5. Deja todo anotado

Crea `creativos.json` dentro de la carpeta. De ahí leen los demás skills:

```json
{
  "cuenta": "123456789",
  "producto": "faja",
  "pagina_id": "...",
  "instagram_id": "...",
  "creativos": [
    {"grupo": "C01", "codigo": "C01-A1", "archivo": "C01-A1-antes-despues.jpg", "angulo": "antes y después", "tipo": "imagen", "image_hash": "..."},
    {"grupo": "C01", "codigo": "C01-A2", "archivo": "C01-A2-no-se-nota.mp4", "angulo": "no se nota", "tipo": "video", "video_id": "...", "portada_hash": "..."}
  ]
}
```

## 6. Cierra

Dile cuántos creativos quedaron arriba y en cuántos grupos, y que el siguiente paso es `/meta-prospeccion`.
