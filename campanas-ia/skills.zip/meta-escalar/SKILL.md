---
name: meta-escalar
description: Escala lo que vende en Meta con una campaña de consolidación que junta los mejores creativos de a 3 por conjunto, con el presupuesto en la campaña. Usar cuando la persona quiera escalar, consolidar ganadores, invertir más en lo que funciona o "meterle más plata".
---

# Escalar: campaña de consolidación

Hablas en español sencillo. Usas solo las herramientas de **meta-ads**. Todo se crea **en pausa**.

**Presupuesto:** mira la moneda (`currency` en `ads_get_ad_accounts`). En COP, CLP, JPY, PYG, CRC, HUF, ISK, IDR, KRW, TWD y VND el valor va tal cual (30.000 COP = `30000`); en las demás monedas, por 100. La herramienta dice "in cents" para todo: no le hagas caso en esas monedas. Después de crear, lee la campaña y confirma que el presupuesto es el que pidió la persona.

## 1. Parte del análisis

En la carpeta de trabajo (la de `creativos.json`, por defecto `mis-anuncios`) lee `analisis.json`. Si no existe o su `fecha` tiene más de 3 días, corre primero `/meta-analisis`.

**Solo entran ganadores firmes: con compras y sin `poca_muestra`.** Un anuncio sin ventas, o con una venta de suerte, no se escala. Si no hay ningún ganador, dilo y recomienda probar creativos nuevos con `/meta-creativos` y `/meta-prospeccion`.

## 2. Pregunta

- **¿Cuánto quieres invertir al día en toda la campaña?** (aquí el presupuesto va en la campaña y Meta lo reparte entre los conjuntos)
- País, destino y marca: léelos de `creativos.json` (o de un conjunto de la prospección con `ads_get_ad_entities`) y confírmalos.

## 3. Muestra el plan y espera el OK

- **Campaña:** `🔵 F2(00N) | MARCA2026 | PRODUCTO | CONSOLIDACION | PAIS | AAAA-MM-DD`, objetivo Ventas, presupuesto diario en la campaña. `PRODUCTO` sale de `creativos.json`. `00N`: el número siguiente a las campañas `🔵 F2(` que ya existen en la cuenta (`ads_get_ad_entities`, nivel campaña, `date_preset` `maximum`).
- **Conjuntos de a 3 ganadores:** `G01 | BROAD | IG-FB`, `G02 | …`. Ordena los ganadores del más barato por venta al más caro y llénalos de a 3. Si sobran 1 o 2, van en el último conjunto. Con un solo ganador también se hace.
- **Anuncios:** con el mismo nombre que tenían en la prospección (léelo con `ads_get_ad_entities`), para comparar.
- Mismo público abierto y, si es a la tienda, sin los compradores.

## 4. Crea

1. `ads_create_campaign`: `objective` `OUTCOME_SALES`, `special_ad_categories` `[]`, `campaign_daily_budget` (regla de moneda).
2. `ads_create_ad_set` por grupo, **sin presupuesto propio**, con `billing_event` `IMPRESSIONS` y la configuración de la prospección (léela de un conjunto de la prospección: `targeting`, `optimization_goal`, `promoted_object`, `destination_type`, `attribution_spec`). Ubicaciones escritas: a la tienda `["facebook", "instagram", "threads", "whatsapp"]`, a WhatsApp `["facebook", "instagram", "whatsapp"]`, y en los dos `"whatsapp_positions": ["status"]`.
3. `ads_create_ad` por ganador **reusando su creativo** (`creative_id` del anuncio original, que sacas con `ads_get_ad_entities`). No se sube nada otra vez.
4. **Comprueba** leyendo campaña (presupuesto), conjuntos (`effective_publisher_platforms`, exclusión, `status`) y anuncios (`status` `PAUSED`; si se leen `IN_PROCESS` es Meta revisándolos, normal).
5. Anota en `creativos.json` la campaña de consolidación y sus anuncios.

## 5. Cierra

- En la prospección, apaga los ganadores que pasaron a consolidación **solo si la persona lo pide**; la prospección sigue viva para probar creativos nuevos.
- Para subir el presupuesto después: **máximo un 20% cada 3 días**. Subirlo de golpe desordena lo que ya funciona.
- Que la mire en el Administrador de anuncios y la prenda, o te diga "préndela".
- En una cuenta de práctica sin ventas, la persona puede marcar ganadores a mano en `analisis.json` para ensayar.
