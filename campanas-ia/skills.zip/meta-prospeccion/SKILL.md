---
name: meta-prospeccion
description: Crea la campaña de prospección en Meta (ventas a público nuevo, a la tienda o a WhatsApp) con un conjunto por cada grupo de 3 creativos, presupuesto por conjunto y nombres ordenados. Usar cuando la persona quiera crear o lanzar una campaña nueva, prospección o "prender anuncios" con los creativos ya subidos.
---

# Campaña de prospección

Hablas en español sencillo. Usas solo las herramientas de **meta-ads**. Todo se crea **en pausa**: nada gasta plata hasta que la persona lo prenda.

## Reglas que no se rompen

- **Presupuesto:** mira la moneda con `ads_get_ad_accounts` (`currency`). En COP, CLP, JPY, PYG, CRC, HUF, ISK, IDR, KRW, TWD y VND el valor va **tal cual** (20.000 COP = `20000`). En USD, EUR, MXN y las demás se multiplica por 100 (20 USD = `2000`). La herramienta dice "in cents" para todo: no le hagas caso en esas monedas. **Después de crear, lee el conjunto y confirma que el presupuesto es el que pidió la persona.**
- **Ubicaciones** siempre escritas dentro de `targeting`, nunca automáticas:
  - A la tienda: `"publisher_platforms": ["facebook", "instagram", "threads", "whatsapp"]`, `"whatsapp_positions": ["status"]`.
  - A WhatsApp: `"publisher_platforms": ["facebook", "instagram", "whatsapp"]`, `"whatsapp_positions": ["status"]`.
  - Así WhatsApp sale solo en Estados: los "mensajes de marketing" de WhatsApp salen caros y se sienten como spam. Al comprobar, mira `effective_publisher_platforms`.
- **Estados:** recién creados, los anuncios se leen `IN_PROCESS` o `PENDING_REVIEW`: es Meta revisándolos y es normal. Lo que vale es que `status` diga `PAUSED`. La herramienta habla de "DRAFT MODE": igual quedan creados en pausa.
- Si una lectura falla por conexión (`ECONNRESET`), repítela una vez. Haz las lecturas de una en una.

## 1. Lee los creativos

Busca `creativos.json` en la carpeta de trabajo (la carpeta abierta; por defecto `mis-anuncios` en el escritorio). Si no existe, dile que primero corra `/meta-creativos`. De ahí salen la cuenta, el producto, la página (`pagina_id`), el Instagram (`instagram_id`) y los creativos. Si falta la página, sácala con `ads_get_ad_account_pages`; si falta el Instagram, con `ads_get_ig_accounts`.

## 2. Pregunta en un solo mensaje

1. **¿A dónde llevamos a la gente?** `web` (compran en la tienda) o `whatsapp` (te escriben).
2. **¿Cuánto quieres gastar al día en cada conjunto?** Muéstrale el total: presupuesto × número de grupos.
3. **¿En qué país o países?**
4. **Marca y año** para el nombre (ejemplo: `FAJAS2026`).
5. Si es `web`: el **link** del producto. Mira los pixeles con `ads_get_datasets`; si hay varios, recomienda el que tenga actividad reciente y pregunta.
6. **¿A quién le vendes y qué problema le resuelves?** Con eso escribes el texto.
7. **¿Algún creativo está hecho con inteligencia artificial?** (Meta pide declararlo y no se cambia después.)

Si es `whatsapp`, avisa: **la página de Facebook debe tener un WhatsApp Business conectado** (en la página: Configuración → Cuentas vinculadas → WhatsApp).

## 3. Escribe el texto

Propón 3 textos principales (cortos, empiezan por el problema del cliente, terminan con una sola acción) y 3 títulos de 2 a 4 palabras que sean un llamado. Numéralos (T1, T2, T3 y A, B, C) para que escoja rápido. No inventes precios, descuentos, garantías ni cifras que la persona no te dio. Si un creativo no tiene que ver con el producto, avísale.

## 4. Muestra el plan y espera el OK

- **Campaña:** `🔵 F2(00N) | MARCA2026 | PRODUCTO | PROSPECCION | PAIS | AAAA-MM-DD`
  - `PRODUCTO` es el de `creativos.json`, en mayúscula.
  - `00N`: busca con `ads_get_ad_entities` (nivel campaña, `date_preset` `maximum`) las campañas que empiezan por `🔵 F2(` y usa el número siguiente. Si no hay, `001`.
  - Busca también que no exista una con el mismo nombre.
- **Un conjunto por grupo:** `C01 | BROAD | IG-FB`, con su presupuesto y sus creativos.
- **Un anuncio por creativo:** `C01-A1 | IMAGEN | angulo` o `C01-A2 | VIDEO | angulo`.
- Público abierto, el país, desde 18 años. En `web`, **sin los que ya compraron**.

Crea solo cuando diga que sí.

## 5. Crea, en este orden

1. **Solo en `web`, el público de compradores para excluir:** busca **por nombre** con `ads_get_ad_account_custom_audiences` uno llamado `COMPRADORES 180D` (Meta lo muestra con tipo `PLATFORM`, por eso se busca por nombre). Si no existe, créalo con `ads_create_custom_audience` tipo WEBSITE: plantilla `VISITORS_BY_URL`, evento `Purchase` del pixel, `retention_seconds` 15552000. En WhatsApp no hay compradores del pixel: sáltalo.
2. **Campaña** con `ads_create_campaign`: `objective` `OUTCOME_SALES`, `special_ad_categories` `[]`, **sin presupuesto en la campaña**.
3. **Un conjunto por grupo** con `ads_create_ad_set`, `daily_budget` (ver la regla de moneda), `bid_strategy` `LOWEST_COST_WITHOUT_CAP`, `billing_event` `IMPRESSIONS` y:
   - `web`: `optimization_goal` `OFFSITE_CONVERSIONS`, `destination_type` `WEBSITE`, `promoted_object` `{"pixel_id": "...", "custom_event_type": "PURCHASE"}`, `targeting` con `excluded_custom_audiences` `[{"id": "<COMPRADORES 180D>"}]`.
   - `whatsapp`: `optimization_goal` `CONVERSATIONS`, `destination_type` `WHATSAPP`, `promoted_object` `{"page_id": "..."}`, `attribution_spec` `[{"event_type": "CLICK_THROUGH", "window_days": 1}]`.
   - En los dos: `targeting` con `geo_locations` (países), `age_min` 18, `targeting_automation` `{"advantage_audience": 1}` y las ubicaciones de arriba.
4. **Un anuncio por creativo** con `ads_create_ad`, con el creativo en línea (`object_story_spec` con `page_id` y, si hay, `instagram_user_id`):
   - Imagen a la tienda: `link_data` con `image_hash`, `message` (texto), `name` (título), `link` y `call_to_action` `{"type": "SHOP_NOW", "value": {"link": "..."}}`.
   - Video a la tienda: `video_data` con `video_id`, `image_hash` = `portada_hash`, `message`, `title`, y el mismo `call_to_action`.
   - A WhatsApp: el link es `https://api.whatsapp.com/send` y `call_to_action` `{"type": "WHATSAPP_MESSAGE", "value": {"app_destination": "WHATSAPP"}}`.
   - En `web`, el pixel en el seguimiento: `tracking_specs` `[{"action.type": ["offsite_conversion"], "fb_pixel": ["<pixel>"]}]`.
5. **Comprueba** con `ads_get_ad_entities` cada conjunto (`targeting`, `daily_budget`, `optimization_goal`, `promoted_object`, `destination_type`, `status`) y cada anuncio (`status`). Si algo no quedó, corrígelo con `ads_update_entity`.
6. Guarda en `creativos.json` el `campana_id`, los `conjunto_id`, el `pixel_id`, el `publico_excluido_id`, el destino, el país, la marca y, en cada creativo, su `ad_id`.

Si un paso falla, explica el error con palabras sencillas y arréglalo. Si se cae a mitad de camino, no vuelvas a crear lo que ya existe: léelo y sigue desde ahí.

## 6. Cierra

- Dile el nombre de la campaña y que la vea en https://adsmanager.facebook.com antes de prenderla.
- **WhatsApp:** el número al que llegan los chats **no se puede leer desde aquí**: lo define la página. Que abra la vista previa de un anuncio en el Administrador de anuncios y toque el botón de WhatsApp: el número que abre es el que va a recibir los mensajes.
- Para prenderla: que use el interruptor en el Administrador de anuncios o te diga "préndela" (activas campaña, conjuntos y anuncios con `ads_activate_entity` y vuelves a leer para confirmar).
- Que no la juzgue antes de 3 días. Después: `/meta-analisis`.
