---
name: meta-analisis
description: Trae las métricas de las campañas de Meta, las evalúa primero por ventas y después por métricas secundarias, y entrega un informe con resumen y detalle por conjunto y por creativo. Usar cuando la persona pregunte cómo van sus campañas, pida un análisis, un informe o qué anuncios funcionan.
---

# Análisis de campañas

Hablas en español sencillo. Usas solo las herramientas de **meta-ads**. **Solo lees: no cambias nada.**

## 1. Pregunta en un solo mensaje

- ¿Qué cuenta y qué periodo? (por defecto, últimos 7 días)
- **¿Cuánto puedes pagar como máximo por una venta?** Sin esa cifra no se puede decir si algo está caro.
- ¿Cuál es el precio de tu producto? Con eso calculas el **retorno mínimo** = precio ÷ máximo por venta (precio 300.000 y máximo 120.000 → hay que lograr al menos 2,5).

## 2. Trae los datos

Tres llamadas a `ads_get_ad_entities`, una por nivel (`campaign`, `adset`, `ad`), solo lo que gastó en el periodo (filtro `amount_spent > 0`), ordenado por gasto, `limit` 500, y en conjuntos y anuncios `include_additional_context: false`. Pide estos campos:

`amount_spent`, `impressions`, `reach`, `frequency`, `link_click`, `website_ctr`, `cost_per_link_click`, `cpm`, `omni_landing_page_view`, `omni_add_to_cart`, `omni_initiated_checkout`, `omni_purchase`, `omni_purchase_values`, `cost_per_omni_purchase`, `purchase_roas`, `results`, `cost_per_result`, `objective`, `status`, `created_time`.

- CTR y costo por clic: usa `website_ctr` y `cost_per_link_click` (clics en el enlace), no `ctr` ni `cpc`, que cuentan cualquier clic.
- Compras: usa `omni_purchase` y dilo en el informe.
- Campañas de WhatsApp: lee `results` y `cost_per_result` (son las conversaciones).
- Si una respuesta es muy grande y llega como archivo, léelo con un script (en Windows, copia el archivo a una carpeta de nombre corto y corre Python con `PYTHONIOENCODING=utf-8`).

Los nombres `C01-A1` atan cada anuncio a su grupo de `creativos.json`. Si la cuenta no se armó con `/meta-creativos`, usa el nombre del anuncio como código.

## 3. Evalúa en este orden

1. **Ventas (lo que manda):** compras, costo por compra contra lo que la persona puede pagar, y retorno contra el retorno mínimo.
2. **Si todavía no hay ventas**, lo secundario, para saber dónde se cae la gente:
   - CTR bajo → el creativo no detiene a la gente: cambiar el creativo.
   - Buen CTR pero pocas visitas → la página carga lento.
   - Visitas pero no carrito → la página o el precio no convencen.
   - Carrito pero no compra → problema en el pago o el envío.
   - Si hay más pagos iniciados que carritos, la tienda se salta el carrito: lee clic → visita → pago → compra.
   - Frecuencia alta → la misma gente ya lo vio mucho: toca creativo nuevo.
   - WhatsApp: costo por conversación, y pregunta cuántas terminaron en venta.
3. **Reglas para decidir:**
   - **Campañas que no son de ventas** (alcance, reconocimiento, video): no se juzgan por compras. Van aparte.
   - **Todavía no se juzga:** lleva menos de 3 días (mira `created_time`) o gastó menos de lo que la persona puede pagar por una venta.
   - **Ganador:** 3 compras o más y costo por compra dentro de lo que puede pagar. Con 1 o 2 compras baratas va como **ganador con poca muestra**, que no se escala todavía.
   - **Perdedor:** gastó más de 2 veces lo que puede pagar por una venta sin ninguna compra, o su costo por compra es más del doble de lo que puede pagar.
   - Lo demás: **en observación**.
   - Si el mismo creativo está en varios conjuntos, súmalo y decide con el total.
   - Un día bueno o malo no cambia nada: se decide con lo acumulado.
   - No uses promedios del mercado que no puedas comprobar: compara contra la meta de la persona y entre sus propios anuncios.

## 4. Entrega el informe

Crea `informe-meta-AAAA-MM-DD.html` en la carpeta de trabajo (la de `creativos.json`; si no hay, `mis-anuncios` en el escritorio). Fondo claro, letra grande, tablas simples. Ábrelo en el navegador. Dos partes:

**Resumen (lo que se lee en 1 minuto):**
- Gasto total, ventas, costo por venta y retorno, contra la meta.
- Una frase de cómo va.
- **Ganadores**, **perdedores** y **en observación**, con su código y su ángulo.
- Las 3 acciones recomendadas, en orden.

**Detalle:**
- Tabla por campaña, por conjunto y por anuncio con todas las métricas.
- En qué paso se cae la gente.
- Qué ángulos y qué creativos funcionan mejor.

Guarda también `analisis.json` en la misma carpeta, para `/meta-apagar` y `/meta-escalar`. En **perdedores** van solo los que siguen prendidos:

```json
{
  "fecha": "AAAA-MM-DD",
  "cuenta": "123456789",
  "periodo": "last_7d",
  "meta_costo_venta": 120000,
  "retorno_minimo": 2.5,
  "ganadores":   [{"codigo": "C01-A2", "ad_id": "...", "creative_id": "...", "campana_id": "...", "conjunto_id": "...", "estado": "ACTIVE", "gasto": 0, "compras": 0, "costo_compra": 0, "retorno": 0, "poca_muestra": false, "angulo": "..."}],
  "perdedores":  [{"codigo": "...", "ad_id": "...", "conjunto_id": "...", "estado": "ACTIVE", "gasto": 0, "compras": 0, "costo_compra": null, "razon": "..."}],
  "observacion": [{"codigo": "...", "ad_id": "...", "gasto": 0, "compras": 0}],
  "no_ventas":   [{"campana": "...", "objetivo": "OUTCOME_AWARENESS", "gasto": 0}]
}
```

## 5. Cierra

Muestra el resumen en el chat y ofrece `/meta-apagar` para los perdedores y `/meta-escalar` si hay ganadores firmes.
