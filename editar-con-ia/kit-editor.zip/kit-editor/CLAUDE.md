# Kit editor de reels

Conviertes tomas en bruto en un reel vertical terminado. **Tú solo decides dos cosas: qué pedazos van (edl.json) y qué receta se usa.** Todo lo demás lo hace el código del kit, que ya está probado. No escribas código nuevo de edición, no toques `remotion/src` ni `kit/` salvo que el usuario lo pida.

## Carpetas

| Carpeta | Qué va |
|---|---|
| `01-material/` | las tomas grabadas (iPhone, Android, cámara; cualquier rotación) |
| `02-musica/` | una pista de música. Efectos opcionales: si el nombre trae `swoosh`, `whoosh`, `impact`, `pop` o `click`, se usan; si no, el kit trae los suyos |
| `03-broll/` | tomas de apoyo. **Solo se usan si tienen relación directa con lo que se dice.** Si dudas, no las uses |
| `04-marca/` | logo PNG **con fondo transparente** (si no es transparente, el kit escribe el nombre en su lugar) |
| `marca.json` | nombre, cargo, colores, fuente, color del estampado de la camiseta |
| `recetas/` | `vende`, `cine`, `premium`, `explicador` |
| `edl.ejemplo.json` | ejemplo con tomas inventadas, solo para copiar la forma |
| `05-exportados/` | los reels terminados y su hoja de revisión |
| `_trabajo/` | archivos intermedios. Se puede borrar |

## El flujo (siempre en este orden)

**0. Instalar (una sola vez por computador)**
Antes de instalar revisa el disco: **se necesitan mínimo 4 GB libres** (instalación unos 1,2 GB y cada render hasta 1,5 GB de temporales). Si hay menos, avísale al usuario antes de seguir.
`python kit/instalar.py`. Debe terminar en `TODO LISTO`. Si dice `QUEDO PENDIENTE`, sigue la instrucción que imprime y vuelve a correrlo.

**1. Preparar** · `python kit/preparar.py`
Endereza la rotación, deja cada toma en 1080x1920 a 30 cuadros, limpia la voz y ubica la cara y el estampado de la camiseta. Revisa que diga `cara ok` en cada toma.

**2. Transcribir** · `python kit/transcribir.py`
Whisper small en el procesador, con tiempo por palabra. Lee `_trabajo/transcripcion.md` completo antes de seguir.

**3. Proponer el plan de cortes** · escribes `edl.json` en la raíz
Lee la transcripción y arma el guion del reel con lo mejor que se dijo. Reglas:
- 25 a 35 segundos. La frase más fuerte va primero (gancho).
- Fuera: conteos ("uno, dos, tres"), tomas fallidas, repeticiones, muletillas, frases que piden otra cosa distinta al llamado a la acción.
- Cada tramo es una frase o media frase completa. Pon `inicio` en el segundo de inicio de la primera palabra y `fin` en el fin de la última, tal como salen en la transcripción. En `archivo` va el nombre de la toma **sin extensión** (`IMG_0257`, no `IMG_0257.MOV`). **El kit ajusta solo cada corte al silencio más cercano**, no intentes afinar a mano.
- El último tramo puede ser un trozo sin voz de 2 segundos con `"cta": true`: ahí sale la tarjeta del llamado a la acción.
- `seccion` agrupa tramos con un nombre corto ("El problema"). La receta premium lo muestra como título de capítulo.
- `frases_fuertes`: lo que debe llevar zoom de golpe. Escríbelas tal como se oyen.
- `palabras_clave`: palabras que se pintan en el color de acento.
- `correcciones`: arregla palabras mal transcritas (`{"superarán": "superar"}`).
- `tarjetas`: solo las usa la receta explicador. `cuando` y `hasta` son palabras que se oyen; `"nada#3"` es la tercera vez que suena "nada".

Mira `edl.ejemplo.json`: tiene todos los campos con tomas inventadas. **Copia la forma, no el contenido.**

**Reglas que el kit cuida solo (y que tú no debes pelear):**
- **Gancho:** sus primeros segundos el título va arriba y los subtítulos justo debajo, al mismo tamaño que el resto. La frase más fuerte puede ir primero sin achicarse.
- **Tamaño de letra:** es fijo por receta. Si no cabe en un sitio, el subtítulo se cambia de sitio; nunca se encoge.
- **Palabras débiles:** ninguna línea termina en "y", "de", "el", "la", "los", "que", "a", "si", "va", "no"... Esas palabras se van con la que sigue. Si una pantalla no cabe en una línea, se parte en dos líneas.
- **Tarjetas:** `hasta` debe ser una palabra que suene **después** del último `cuando` de esa tarjeta. Si no, el kit lo corrige y avisa. Cada tarjeta se queda mínimo 2,5 s después de su último ítem y, si el siguiente texto llega pronto, espera hasta él: el panel nunca queda vacío.

**Obligatorio:** antes de renderizar, muéstrale al usuario el plan en una tabla corta (tramo, qué se dice, por qué) y sigue.

**4. Revisar los subtítulos sin gastar render** · `python kit/base.py --receta vende --solo-linea`
Lee `_trabajo/subtitulos_vende.txt`. Cada línea es una pantalla: zona (`pecho` entre la barbilla y el estampado, `arriba` sobre la cabeza), tamaño, aviso y texto (` / ` separa dos líneas). Si dice `APRETADO`, el espacio libre es justo; si dice `ANCHO`, esa pantalla tiene demasiadas letras: parte el tramo en dos. Si falta una palabra al comienzo de un tramo, baja su `inicio` 0,2 s. Si se cuela una palabra de otra frase, ajusta el `fin`.

**5. Render** · `python kit/render.py --receta vende` (o `--receta todas`)
Hace el video base, dibuja todo en Remotion, mezcla la voz con música y efectos, deja el volumen en -14 LUFS y guarda `05-exportados/[titulo]_[receta]_vN.mp4`. Nunca sobreescribe: cada render es una versión nueva.
Para probar un pedazo rápido: `python kit/render.py --receta vende --desde 10 --hasta 14`.

**6. Revisar fotogramas** · sale solo al final del render (`..._hoja.jpg`), o `python kit/revisar.py ruta.mp4 receta`
**Abre la hoja y mírala.** Debe cumplir:
- lo que imprime `Subtitulos:` (líneas que terminan en palabra débil, cambios de tamaño, pantallas apretadas o anchas)
- ninguna frase partida de forma rara
- nada encima de la cara ni del estampado de la camiseta
- textos que se leen en un celular
- volumen entre -15 y -13 LUFS, pico menor a -1 dB
Si algo falla, corrige `edl.json` (o `marca.json`) y vuelve al paso 5. Máximo 3 vueltas; si sigue mal, dile al usuario qué falla.

**7. Entregar** · ruta del MP4 y de la hoja, duración, receta y lo que quedó pendiente.

**8. Limpiar** · `python kit/limpiar.py` borra los archivos intermedios y los temporales de Remotion. `python kit/limpiar.py --todo` borra además `_trabajo` y la copia del navegador (unos 280 MB en `AppData\Local\kit-reels-navegador`); después hay que volver a instalar. Nunca toca tus videos ni `05-exportados`. No lo corras mientras renderizas.

## Las recetas

| Receta | Cómo se ve |
|---|---|
| `vende` | creador: cortes rápidos, zoom de golpe, whoosh, subtítulos grandes con la palabra activa en caja amarilla |
| `cine` | color cálido y frío, grano, viñeta, franjas negras, zoom lento, subtítulos finos, fundidos, música al frente |
| `premium` | color sobrio, letra fina espaciada, títulos de capítulo, barra de nombre, sin efectos de sonido, ritmo con aire |
| `explicador` | panel gráfico arriba con listas, chulos y equis dibujados que salen con las palabras clave |

Para una receta nueva: copia un `.json` de `recetas/`, cámbiale el nombre y los valores. Colores y fuente salen de `marca.json`.

## Si algo falla

| Mensaje | Qué hacer |
|---|---|
| `Quedan X GB libres` o `ENOSPC` | disco lleno (el render pide 1,5 GB). `python kit/limpiar.py`, borra versiones viejas de `05-exportados` y repite |
| `Failed to launch the browser` o `ENOENT` | `python kit/instalar.py` (copia el navegador a una ruta corta o usa el Chrome del computador) |
| `cara NO DETECTADA` | la toma no tiene la cara de frente. Sirve igual; el zoom se centra arriba |
| subtítulos encima del estampado | ajusta `estampado_hsv` en `marca.json` al color del estampado, o fija `subtitulos_y` (en píxeles, 0 arriba y 1920 abajo) |
| `frase fuerte no encontrada` | escríbela igual que en la transcripción |
| `APRETADO` | en un zoom fuerte queda poco espacio. Baja `punch` en la receta o quita esa frase de `frases_fuertes` |
| `ANCHO` | la pantalla tiene muchas letras. Parte ese tramo en dos o baja `max_caracteres` en la receta |
| `su 'hasta' llega antes que su ultimo item` | ya quedó corregido; para la próxima, pon en `hasta` una palabra posterior |
| volumen fuera de -14 | revisa que la voz no esté saturada en la toma original |
| ffmpeg no aparece | Windows: `winget install --id Gyan.FFmpeg -e`. Mac: `brew install ffmpeg` |

## Nunca
- Voz generada con IA. Siempre la voz original.
- Voseo en textos de pantalla (tienes, puedes, escríbeme).
- Tomas de apoyo que no tengan que ver con lo que se dice.
- Cifras en pantalla que la persona no dijo.
