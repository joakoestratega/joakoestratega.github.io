# Paso 4. Convierte edl.json en: video base (cortes + color de la receta), voz editada y linea de tiempo
# (subtitulos por frases, zooms, zonas libres, tarjetas) que Remotion usa para dibujar.
# Uso: python kit/base.py --receta vende
import os, sys, wave
import numpy as np
from concurrent.futures import ThreadPoolExecutor
from comun import *

# Palabras que nunca cierran una linea de subtitulo.
# DURAS: articulos, preposiciones, conjunciones y pronombres: se pegan siempre a la palabra que sigue.
# SUAVES: "no", "es", "va"...: se evita cortar despues de ellas, pero no se pegan a la fuerza.
DURAS = set("y e o u ni de del a al la el los las lo un una unos unas que en con por para sin mi mis tu tus su sus se me te "
            "nos le les si ese esa esos esas este esta estos estas pero porque como cuando".split())
SUAVES = set("no ya muy mas tan va van vas voy ha he has han hay es son fue era".split())
SUAVES |= {"más"}
DEBILES = DURAS | SUAVES


def deb(t):
    """minusculas sin signos pero CON tildes: 'está' (verbo) no es 'esta'."""
    return str(t).lower().strip(" ,.;:¿?¡!\"'")
SR = 48000
ZOOM_MAX = 1.3       # mas que esto y el video de 1080 se ve blando
PASO = 0.01          # envolvente de energia cada 10 ms
MARGEN_IG_ARRIBA, MARGEN_IG_ABAJO = 170, 1540   # lo que tapan los botones de Instagram/TikTok


# ---------- energia de la voz: para cortar en silencio y no comerse silabas ----------
_cache = {}
def voz_toma(toma):
    if toma not in _cache:
        with wave.open(os.path.join(VOCES, toma + ".wav")) as w:
            x = np.frombuffer(w.readframes(w.getnframes()), np.int16).astype(np.float32) / 32768
        n = int(SR * PASO)
        env = 20 * np.log10(np.sqrt((x[: len(x) // n * n].reshape(-1, n) ** 2).mean(1)) + 1e-6)
        piso = np.percentile(env, 10)
        _cache[toma] = (x, env, max(piso + 14, np.percentile(env, 60) - 12))
    return _cache[toma]


def habla(toma, t):
    _, env, thr = voz_toma(toma)
    i = int(t / PASO)
    return 0 <= i < len(env) and env[i] > thr


def ajustar_inicio(toma, t):
    _, env, thr = voz_toma(toma)
    i = int(t / PASO)
    if i < len(env) and env[max(i, 0)] <= thr:                # cae en silencio: avanza hasta que empieza a hablar
        for j in range(i, min(len(env), i + 70)):
            if env[j] > thr:
                return max(0.0, j * PASO - 0.07)
        return t
    a, b = max(0, i - 8), min(len(env), i + 8)              # cae en medio de la voz: busca el valle mas cercano
    return (a + int(np.argmin(env[a:b]))) * PASO


def ajustar_fin(toma, t, dur):
    _, env, thr = voz_toma(toma)
    i = min(int(t / PASO), len(env) - 1)
    if env[i] <= thr:                                       # silencio: retrocede hasta la ultima silaba
        for j in range(i, max(0, i - 50), -1):
            if env[j] > thr:
                return min(dur, j * PASO + 0.12)
        return t
    a, b = max(0, i - 6), min(len(env), i + 14)
    return min(dur, (a + int(np.argmin(env[a:b]))) * PASO + 0.02)


def palabra_real(toma, s, e):
    """Whisper estira la palabra que sigue a un silencio hacia atras. Se mueve al momento en que de verdad suena."""
    _, env, thr = voz_toma(toma)
    i0, i1 = int(s / PASO), min(int(e / PASO), len(env) - 1)
    voz = env[i0:i1 + 1] > thr
    if not voz.any():                                       # toda la palabra cae en silencio: suena justo despues
        for j in range(i1, min(len(env), i1 + 80)):
            if env[j] > thr:
                return j * PASO - 0.03, j * PASO + max(0.15, e - s if e - s < 0.5 else 0.25)
        return s, e
    run, ultimo = 0, None
    for k, v in enumerate(voz):
        if not v:
            run += 1
        else:
            if run >= 6:
                ultimo = k
            run = 0
    if voz[0] and ultimo is None:
        return s, e
    k = ultimo if ultimo is not None else int(np.argmax(voz))
    return max(s, (i0 + k) * PASO - 0.03), e


# ---------- utilidades de tiempo de palabras ----------
def buscar(palabras, patron, n=1):
    """Ubica 'texto' o 'texto#2' dentro de la linea de tiempo final. Devuelve (i0, i1) o None."""
    if "#" in patron:
        patron, n = patron.rsplit("#", 1)
        n = int(n)
    obj = [norm(x) for x in patron.split() if norm(x)]
    vistos = 0
    for i in range(len(palabras) - len(obj) + 1):
        if all(norm(palabras[i + k]["raw"]) == obj[k] or norm(palabras[i + k]["t"]) == obj[k] for k in range(len(obj))):
            vistos += 1
            if vistos == n:
                return i, i + len(obj) - 1
    return None


def factor_ancho(sub):
    """Ancho medio de una letra en Montserrat, en proporcion al tamano (medido en los renders de prueba)."""
    if sub.get("mayusculas"):
        k = 0.78 if sub.get("peso", 700) >= 800 else 0.72
    else:
        k = 0.64 if sub.get("peso", 700) >= 700 else 0.6
    return k * sub.get("tam", 80) + sub.get("espaciado", 0)


def ancho_disponible(sub):
    return 860 if sub.get("caja") else 900


def agrupar(pal, maxp, maxc):
    """Parte las palabras en pantallas cortas. Corta en limites naturales y nunca deja una linea terminando en palabra debil."""
    grupos, trozo = [], []
    for i, p in enumerate(pal):
        trozo.append(i)
        if i < len(pal) - 1 and deb(p["t"]) in DEBILES and pal[i + 1]["desde"] - p["hasta"] < 1.2:
            continue                                        # "y", "los", "de"... siempre van con la palabra que sigue
        fin = (i == len(pal) - 1 or p["corte_frase"] or pal[i + 1]["tramo"] != p["tramo"]
               or pal[i + 1]["desde"] - p["hasta"] > 0.35)
        if fin:
            grupos += _partir(pal, trozo, maxp, maxc)
            trozo = []
    return grupos


def _unidades(pal, idx):
    """Pega cada palabra dura a la que sigue: 'el presupuesto', 'de la pauta'."""
    u, act = [], []
    for k in idx:
        act.append(k)
        if deb(pal[k]["t"]) not in DURAS:
            u.append(act); act = []
    if act:
        if u:
            u[-1] += act
        else:
            u.append(act)
    return u


def _largo(pal, ks):
    return sum(len(pal[k]["t"]) for k in ks) + len(ks) - 1


def _partir(pal, idx, maxp, maxc):
    us = _unidades(pal, idx)
    n = len(us)
    INF = 1e9
    mejor, desde = [0] + [INF] * n, [0] * (n + 1)
    for j in range(1, n + 1):
        for i in range(j - 1, -1, -1):
            ks = [k for u in us[i:j] for k in u]
            ch = _largo(pal, ks)
            if j - i > 1 and (len(ks) > maxp + 2 or ch > 2 * maxc):
                break                                       # una pantalla tiene maximo dos lineas
            c = 10
            if deb(pal[ks[-1]]["t"]) in SUAVES and j < n:
                c += 40                                     # evita "no lo va / a arreglar"
            if ch > maxc:
                c += 25                                     # dos lineas solo si evita un corte feo
            if len(ks) == 1 and n > 1 and len(pal[ks[0]]["t"]) < 5:
                c += 6
            c += abs(ch - maxc * 0.6) * 0.15
            if mejor[i] + c < mejor[j]:
                mejor[j], desde[j] = mejor[i] + c, i
    cortes, j = [], n
    while j > 0:
        cortes.append((desde[j], j))
        j = desde[j]
    return [[k for u in us[a:b] for k in u] for a, b in reversed(cortes)]


def lineas_de(pal_g, maxc):
    """Si una pantalla no cabe en una linea, se parte en dos por el punto menos malo."""
    txt = [w["t"] for w in pal_g]
    if _largo_txt(txt) <= maxc or len(txt) < 2:
        return [list(range(len(txt)))]
    mejor, corte = None, 1
    for c in range(1, len(txt)):
        a, b = _largo_txt(txt[:c]), _largo_txt(txt[c:])
        pena = max(a, b) + (100 if deb(txt[c - 1]) in DURAS else 30 if deb(txt[c - 1]) in SUAVES else 0)
        if mejor is None or pena < mejor:
            mejor, corte = pena, c
    return [list(range(corte)), list(range(corte, len(txt)))]


def _largo_txt(t):
    return sum(len(x) for x in t) + len(t) - 1


# ---------- principal ----------
def construir(nombre_receta, solo_linea=False):
    edl = leer_json(os.path.join(RAIZ, "edl.json"))
    receta = leer_json(os.path.join(RAIZ, "recetas", nombre_receta + ".json"))
    marca = leer_json(os.path.join(RAIZ, "marca.json"), {})
    tomas = leer_json(os.path.join(TRAB, "tomas.json"))
    trans = leer_json(os.path.join(TRAB, "transcripcion.json"))
    corr = {norm(k): v for k, v in edl.get("correcciones", {}).items()}
    carpeta(PUBLICO)
    seg_dir = carpeta(TRAB, "segmentos", nombre_receta)
    aire = receta.get("aire_entre_secciones", 0)

    # 1. tramos ajustados a cuadros exactos
    tramos, t_out = [], 0
    for k, tr in enumerate(edl["tramos"]):
        toma = nombre_toma(tr["archivo"])
        if toma not in tomas:
            raise SystemExit(f"[ERROR] tramo {k + 1}: la toma {tr['archivo']} no esta en 01-material o falta preparar")
        dur = tomas[toma]["duracion"]
        a, b = float(tr["inicio"]), float(tr["fin"])
        if not tr.get("cta") and not tr.get("exacto"):
            a, b = ajustar_inicio(toma, a), ajustar_fin(toma, b, dur)
        sig = edl["tramos"][k + 1] if k + 1 < len(edl["tramos"]) else None
        if aire and sig and sig.get("seccion") != tr.get("seccion") and not sig.get("cta"):
            extra = 0
            while extra < aire and b + extra + 0.05 < dur and not habla(toma, b + extra + 0.05):
                extra += 0.05
            b += extra
        fa, fb = fr(a), min(fr(b), int(dur * FPS) - 1)
        if fb - fa < 6:
            raise SystemExit(f"[ERROR] tramo {k + 1} ({tr['archivo']} {tr['inicio']}-{tr['fin']}) queda de menos de 0,2 s")
        tramos.append({**tr, "toma": toma, "fa": fa, "fb": fb, "o": t_out})
        t_out += fb - fa
    total = t_out

    # 2. palabras en la linea de tiempo final
    pal = []
    for k, tr in enumerate(tramos):
        if tr.get("cta"):
            continue
        a, b = tr["fa"] / FPS, tr["fb"] / FPS
        for w in trans.get(tr["toma"], []):
            ws, we = palabra_real(tr["toma"], w["s"], w["e"])
            solape = min(we, b) - max(ws, a)
            if solape < 0.5 * (we - ws) and solape < 0.3:  # la palabra va en el tramo donde mas suena
                continue
            s = max(ws, a)
            e = min(max(we, s + 0.08), b)
            raw = w["w"]
            limpio = raw.strip(" ,.;:¿?¡!\"'")
            txt = corr.get(norm(limpio), limpio)
            o = tr["o"] / FPS
            pal.append({"t": txt, "raw": limpio, "desde": round(o + s - a, 3), "hasta": round(o + e - a, 3), "tramo": k,
                        "corte_frase": raw.rstrip()[-1:] in ".,;:?!"})
    claves = {norm(x) for x in edl.get("palabras_clave", [])}
    for p in pal:
        p["clave"] = norm(p["t"]) in claves or norm(p["raw"]) in claves

    # 3. pantallas de subtitulos
    sub = receta["subtitulos"]
    grupos = []
    maxc = min(sub.get("max_caracteres", 18), int(ancho_disponible(sub) / factor_ancho(sub)))
    for g in agrupar(pal, sub.get("max_palabras", 3), maxc):
        ws = [pal[i] for i in g]
        grupos.append({"desde": ws[0]["desde"], "hasta": ws[-1]["hasta"], "tramo": ws[0]["tramo"], "lineas": lineas_de(ws, maxc),
                       "palabras": [{"t": w["t"], "desde": w["desde"], "hasta": w["hasta"], "clave": w["clave"]} for w in ws]})
    for i, g in enumerate(grupos):
        nxt = grupos[i + 1]["desde"] if i + 1 < len(grupos) else total / FPS
        g["hasta"] = round(min(nxt, g["hasta"] + 0.45) if nxt - g["hasta"] > 0.5 else nxt, 3)

    # 4. frases fuertes (punch-in), cta, gancho, capitulos
    fuertes = []
    for f in edl.get("frases_fuertes", []):
        n = 1
        while True:
            r = buscar(pal, f"{f}#{n}")
            if not r:
                break
            fuertes.append((pal[r[0]]["desde"], pal[r[1]]["hasta"]))
            n += 1
        if n == 1:
            print(f"  [AVISO] frase fuerte no encontrada en lo que se oye: '{f}'")
    cta_desde = next((tr["o"] / FPS for tr in tramos if tr.get("cta")), max(0, total / FPS - receta["cta"]["segundos"]))
    caps, previa, num = [], None, 0
    for tr in tramos:
        s = tr.get("seccion")
        if s and s != previa and tr is not tramos[0] and not tr.get("cta"):
            num += 1
            caps.append({"texto": s, "num": num, "desde": round(tr["o"] / FPS, 3)})
        previa = s

    # 5. cortes con zoom y zonas libres (sin cara ni estampado)
    zc = receta["zoom"]
    modo = receta.get("encuadre", {}).get("modo", "natural")
    panel = receta.get("encuadre", {}).get("alto_panel", 0) if modo == "panel" else 0
    franja = receta.get("look", {}).get("franjas", 0)
    cortes, alt = [], 0
    for k, tr in enumerate(tramos):
        info = tomas[tr["toma"]]
        c, e = info["cara"], info["estampado"]
        d0, d1 = tr["o"] / FPS, (tr["o"] + tr["fb"] - tr["fa"]) / FPS
        prev = tramos[k - 1]["toma"] if k else None
        alt = alt + 1 if prev == tr["toma"] else 0          # misma toma seguida: alterna plano para que el corte se note
        base_z = tr.get("zoom") if isinstance(tr.get("zoom"), (int, float)) else zc.get("alterno", [1.0])[alt % len(zc.get("alterno", [1.0]))]
        push = zc.get("push_por_segundo", 0) * (2 if tr.get("zoom") == "push" else 1)
        s1 = base_z * (1 + push * (d1 - d0))
        pun = [(max(a, d0), min(b, d1)) for a, b in fuertes if a < d1 and b > d0] if zc.get("punch", 1) > 1 else []
        if tr.get("zoom") == "punch":
            pun.append((d0, d1))
        smax = max(s1, base_z) * (zc.get("punch", 1) if pun else 1)
        cx, cy = c["cx"], c["cy"]
        Y = lambda y, s: cy + (y - cy) * s
        hair, chin = c["y"] - 0.3 * c["h"], c["y"] + 1.08 * c["h"]
        dy = 0
        if panel:
            dy = int(min(panel, max(0, panel + 40 - Y(hair, smax))))
        chin_s = max(Y(chin, s) for s in (base_z, smax)) + dy
        logo_s = (min(Y(e["y"], s) for s in (base_z, smax)) + dy) if e else None
        pecho = [chin_s + 18, min(MARGEN_IG_ABAJO, (logo_s - 18) if logo_s else chin_s + 380)]
        arriba = [max(MARGEN_IG_ARRIBA, franja + 40, panel + 20), min(Y(hair, s) for s in (base_z, smax)) + dy - 24]
        cortes.append({"desde": round(d0, 3), "hasta": round(d1, 3), "cx": cx, "cy": cy, "dy": dy,
                       "s0": round(base_z, 4), "s1": round(s1, 4), "punch": [[round(a, 3), round(b, 3)] for a, b in pun],
                       "seccion": tr.get("seccion"), "cta": bool(tr.get("cta")),
                       "zonaPecho": [round(v) for v in pecho], "zonaArriba": [round(v) for v in arriba],
                       "_p": (hair, chin, e["y"] if e else None)})

    # 5b. donde va cada texto: zona libre real en cada instante (cara y estampado ya con su zoom)
    sup = max(MARGEN_IG_ARRIBA, franja + 40, panel + 20)
    inf = min(MARGEN_IG_ABAJO, H - franja - 60)

    def zonas(t0, t1):
        pe, ar = [0, 1e9], [sup, 1e9]
        t = t0
        while t <= t1 + 1e-6:
            c = next((x for x in cortes if x["desde"] <= t < x["hasta"]), cortes[-1])
            s = c["s0"] + (c["s1"] - c["s0"]) * (t - c["desde"]) / max(0.01, c["hasta"] - c["desde"])
            if any(a <= t < b for a, b in c["punch"]):
                s *= zc.get("punch", 1)
            s = min(s, ZOOM_MAX)
            Y = lambda y: c["cy"] + (y - c["cy"]) * s + c["dy"]
            hair, chin, logo = c["_p"]
            pe = [max(pe[0], Y(chin) + 22), min(pe[1], (Y(logo) - 34) if logo else Y(chin) + 380, inf)]
            ar[1] = min(ar[1], Y(hair) - 24)
            t += 1 / 15
        return pe, ar

    tam = sub.get("tam", 80)
    necesita = tam * 1.2 + sub.get("borde", 0) + (36 if sub.get("caja") else 10 if sub.get("fondo") else 0)
    fija = marca.get("subtitulos_y")
    hook_fin = receta["gancho"]["segundos"] if edl.get("gancho") else 0
    alto_gancho = receta["gancho"].get("alto", 120)          # franja reservada al titulo del gancho
    corrida = []

    def cerrar():
        if corrida:
            lo = max(c[1] for c in corrida); hi = min(c[2] for c in corrida)
            for g, _, _ in corrida:
                g["y"] = round((lo + hi) / 2)
            corrida.clear()

    # La letra NUNCA se achica: si no cabe en una zona, se pasa a la otra.
    # Una sola zona preferida para todo el video: pecho si cabe, si no arriba de la cabeza.
    zs = {id(g): zonas(g["desde"] + 1 / FPS, max(g["desde"] + 1 / FPS, g["hasta"] - 1 / FPS)) for g in grupos}
    libres = [(zs[id(g)][0][1] - zs[id(g)][0][0], zs[id(g)][1][1] - zs[id(g)][1][0]) for g in grupos if g["desde"] >= hook_fin]
    preferida = sub.get("zona", "auto")
    if preferida == "auto" and libres:
        cabe_p = sum(1 for x in libres if x[0] >= necesita) / len(libres)
        cabe_a = sum(1 for x in libres if x[1] >= necesita) / len(libres)
        preferida = "pecho" if cabe_p >= 0.8 or cabe_p >= cabe_a else "arriba"
        print(f"  zona de subtitulos: {preferida} (cabe en el pecho {cabe_p:.0%}, arriba {cabe_a:.0%}; alto {necesita:.0f} px)")
    for g in grupos:
        g["tam"] = tam
        if sub.get("zona") == "panel":
            g.update(zona="panel", y=panel - 95, alto=150, nota="")
            continue
        if fija:
            g.update(zona="fija", y=fija, alto=necesita, nota="")
            continue
        pe, ar = zs[id(g)]
        necesita_g = necesita + (len(g["lineas"]) - 1) * tam * 1.15
        en_gancho = g["desde"] < hook_fin
        if en_gancho:                                        # durante el gancho, justo debajo de su titulo
            ar = [ar[0] + alto_gancho + 12, ar[1]]
        opciones = {"pecho": pe, "arriba": ar}
        if en_gancho:
            orden = ["arriba", "pecho"]
        elif sub.get("zona") in ("pecho", "arriba"):
            orden = [sub["zona"]]                            # la receta fija la zona (premium: arriba van capitulos y nombre)
        else:
            orden = [preferida, "arriba" if preferida == "pecho" else "pecho"]
        zona = next((z for z in orden if opciones[z][1] - opciones[z][0] >= necesita_g), None)
        nota = ""
        if not zona:                                         # no cabe en ninguna: la de mas espacio, sin achicar
            zona = max(orden, key=lambda z: opciones[z][1] - opciones[z][0])
            nota = "APRETADO"
        z = opciones[zona]
        lo, hi = z[0] + necesita_g / 2, z[1] - necesita_g / 2
        y = lo if (en_gancho and zona == "arriba") else (z[0] + z[1]) / 2
        g.update(zona=zona, y=round(y if lo <= hi else (z[0] + z[1]) / 2), alto=round(z[1] - z[0]), nota=nota)
        if lo > hi or en_gancho:
            cerrar()
            continue
        # misma altura mientras se pueda: el subtitulo no salta de un corte a otro
        if corrida and (corrida[0][0]["zona"] != zona or max(lo, *[c[1] for c in corrida]) > min(hi, *[c[2] for c in corrida])):
            cerrar()
        corrida.append((g, lo, hi))
    cerrar()
    k_ancho = factor_ancho(sub)
    for g in grupos:
        larga = max(_largo_txt([g["palabras"][k]["t"] for k in ln]) for ln in g["lineas"])
        if larga * k_ancho > ancho_disponible(sub):
            g["nota"] = (g["nota"] + " ANCHO").strip()
        if g["nota"]:
            print(f"  [AVISO] subtitulo de {g['desde']:.1f}s: {g['nota']} (zona {g['zona']}, {g['alto']} px libres)")

    def zona_arriba(t0, t1):
        if panel:
            return [90, panel - 165]
        return [round(v) for v in zonas(t0, t1)[1]]
    gancho_zona = zona_arriba(0, max(hook_fin, 0.1))
    if not panel:
        bajo = [g["y"] - (necesita + (len(g["lineas"]) - 1) * tam * 1.15) / 2 for g in grupos if g["desde"] < hook_fin and g["zona"] == "arriba"]
        gancho_zona = [gancho_zona[0], round(min([gancho_zona[0] + alto_gancho] + [x - 8 for x in bajo]))]
    for c in caps:
        c["zona"] = zona_arriba(c["desde"], c["desde"] + 1.8)
    nb = receta.get("barra_nombre", {})
    nombre_desde, nombre_zona = None, None
    if nb.get("mostrar"):
        d = nb.get("desde", "auto")
        if d == "auto":                                      # primer hueco sin gancho ni capitulo
            d = hook_fin + 0.4
            ocupado = [(c["desde"] - 0.2, c["desde"] + 2.0) for c in caps] if receta.get("capitulos") else []
            while any(a < d + nb.get("segundos", 2.5) and d < b for a, b in ocupado):
                d += 0.1
        nombre_desde = round(min(d, cta_desde - nb.get("segundos", 2.5)), 2)
        nombre_zona = zona_arriba(nombre_desde, nombre_desde + nb.get("segundos", 2.5))
    for c in cortes:
        c.pop("_p", None)

    # 6. tarjetas (receta explicador)
    tarjetas = []
    for tj in edl.get("tarjetas", []):
        def t_de(p, fin=False):
            if p is None:
                return None
            if isinstance(p, (int, float)):
                return float(p)
            r = buscar(pal, p)
            if not r:
                print(f"  [AVISO] tarjeta: no encontre '{p}' en lo que se oye")
                return None
            return pal[r[1]]["hasta"] if fin else pal[r[0]]["desde"]
        t0 = t_de(tj.get("cuando"))
        if t0 is None:
            continue
        items = []
        for it in tj.get("items", []):
            ti = t_de(it.get("cuando"))
            items.append({**it, "desde": round(ti if ti is not None else t0, 3)})
        tarjetas.append({**tj, "desde": round(t0, 3), "items": items, "hasta": t_de(tj.get("hasta"), True)})
    tarjetas.sort(key=lambda x: x["desde"])
    for i, tj in enumerate(tarjetas):
        ultimo = max([tj["desde"]] + [it["desde"] for it in tj["items"]])
        if tj["hasta"] is not None and tj["hasta"] <= ultimo + 0.3:
            print(f"  [AVISO] tarjeta '{tj.get('titulo') or tj.get('texto')}': su 'hasta' llega antes que su ultimo item. Se corrige solo")
            tj["hasta"] = None
        fin = max(tj["hasta"] or 0, ultimo + 2.5)             # cada tarjeta se queda 2,5 s despues de su ultimo item
        sig = tarjetas[i + 1]["desde"] if i + 1 < len(tarjetas) else cta_desde
        if sig - fin < 4:
            fin = sig                                        # hueco corto: la tarjeta espera a la siguiente (panel nunca vacio)
        if fin > sig:
            print(f"  [AVISO] la tarjeta de {tj['desde']:.1f}s se corta {sig - ultimo:.1f}s despues de su ultimo item: empieza la siguiente")
        tj["hasta"] = round(min(fin, sig, cta_desde), 3)

    # 7. logo solo si tiene fondo transparente
    logo = None
    ruta_logo = os.path.join(RAIZ, marca.get("logo") or "")
    if marca.get("logo") and os.path.isfile(ruta_logo):
        try:
            import cv2
            img = cv2.imdecode(np.fromfile(ruta_logo, np.uint8), cv2.IMREAD_UNCHANGED)
            if img is not None and img.ndim == 3 and img.shape[2] == 4 and img[:, :, 3].min() < 10:
                import shutil
                shutil.copy(ruta_logo, os.path.join(PUBLICO, "logo.png"))
                logo = "logo.png"
            else:
                print("  [AVISO] el logo no tiene fondo transparente: se usa el nombre escrito en su lugar")
        except Exception as ex:
            print("  [AVISO] no pude leer el logo:", ex)
    fuente = marca.get("fuente_archivo")
    if fuente and os.path.isfile(os.path.join(RAIZ, fuente)):
        import shutil
        shutil.copy(os.path.join(RAIZ, fuente), os.path.join(PUBLICO, os.path.basename(fuente)))
        fuente = os.path.basename(fuente)
    else:
        fuente = None

    props = {"video": f"base_{nombre_receta}.mp4", "duracion": total, "receta": receta, "marca": {**marca, "fuente_archivo": fuente},
             "logo": logo, "cortes": cortes, "grupos": grupos, "fuertes": [[round(a, 3), round(b, 3)] for a, b in fuertes],
             "gancho": {"texto": edl.get("gancho", ""), "hasta": hook_fin, "zona": gancho_zona}, "nombreZona": nombre_zona, "nombreDesde": nombre_desde,
             "cta": {**edl.get("cta", {}), "desde": round(cta_desde, 3)}, "capitulos": caps, "tarjetas": tarjetas}
    escribir_json(os.path.join(PUBLICO, f"props_{nombre_receta}.json"), props)

    # texto para revisar a ojo las pantallas de subtitulos
    with open(os.path.join(TRAB, f"subtitulos_{nombre_receta}.txt"), "w", encoding="utf-8") as f:
        for g in grupos:
            f.write(f"{g['desde']:6.2f}-{g['hasta']:6.2f} {g['zona']:>6} y={g['y']:4} {g['tam']:3}px {g['nota'] or '-':8} " + " / ".join(" ".join(g["palabras"][k]["t"].upper() if g["palabras"][k]["clave"] else g["palabras"][k]["t"] for k in ln) for ln in g["lineas"]) + "\n")
    if solo_linea:
        return props

    # 8. video base: cada tramo con el color de la receta, y union sin recodificar
    look = receta.get("look", {})
    vf = ",".join(x for x in [look.get("ffmpeg"), f"noise=alls={look['grano']}:allf=t" if look.get("grano") else None,
                               f"fps={FPS}", "format=yuv420p"] if x)

    def segmento(k):
        tr = tramos[k]
        out = os.path.join(seg_dir, f"s{k:02d}.mp4")
        ffmpeg("-ss", f"{tr['fa'] / FPS:.4f}", "-i", os.path.join(TOMAS, tr["toma"] + ".mp4"), "-frames:v", str(tr["fb"] - tr["fa"]),
               "-vf", vf, "-an", "-c:v", "libx264", "-preset", "veryfast", "-crf", "14", "-g", "15", "-r", str(FPS), out)
        return f"file 's{k:02d}.mp4'"

    with ThreadPoolExecutor(4) as ex:
        lista = list(ex.map(segmento, range(len(tramos))))
    with open(os.path.join(seg_dir, "lista.txt"), "w", encoding="utf-8") as f:   # nombres relativos: las tildes no rompen el concat
        f.write("\n".join(lista) + "\n")
    salida = os.path.join(PUBLICO, f"base_{nombre_receta}.mp4")
    ffmpeg("-f", "concat", "-safe", "0", "-i", os.path.join(seg_dir, "lista.txt"), "-c", "copy", "-movflags", "+faststart", salida)
    import shutil
    shutil.rmtree(seg_dir, ignore_errors=True)               # los pedazos ya estan dentro del video base
    real = int(round(duracion(salida) * FPS))
    if abs(real - total) > 2:
        print(f"  [AVISO] el video base dura {real} cuadros y la linea de tiempo {total}")

    # 9. voz editada, cortada al cuadro y con micro fundidos (sin clics)
    partes = []
    for tr in tramos:
        x = voz_toma(tr["toma"])[0]
        a, n = int(tr["fa"] / FPS * SR), int((tr["fb"] - tr["fa"]) / FPS * SR)
        trozo = x[a:a + n].copy() if not tr.get("cta") else np.zeros(n, np.float32)
        trozo = np.pad(trozo, (0, n - len(trozo)))
        f = int(0.008 * SR)
        trozo[:f] *= np.linspace(0, 1, f)
        trozo[-f:] *= np.linspace(1, 0, f)
        partes.append(trozo)
    voz = np.concatenate(partes)
    with wave.open(os.path.join(TRAB, f"voz_{nombre_receta}.wav"), "wb") as w:
        w.setnchannels(1); w.setsampwidth(2); w.setframerate(SR)
        w.writeframes((np.clip(voz, -1, 1) * 32767).astype(np.int16).tobytes())
    print(f"  base lista: {total} cuadros = {total / FPS:.1f} s, {len(tramos)} cortes, {len(grupos)} pantallas de subtitulos")
    return props


if __name__ == "__main__":
    if "--receta" not in sys.argv:
        raise SystemExit("Uso: python kit/base.py --receta vende")
    r = sys.argv[sys.argv.index("--receta") + 1]
    with Cronometro(f"base {r}"):
        construir(r, solo_linea="--solo-linea" in sys.argv)
