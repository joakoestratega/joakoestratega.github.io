# Instalacion del kit. Un solo comando:  python kit/instalar.py
# No pide permisos de administrador: todo queda dentro de la carpeta del kit o en la carpeta del usuario.
# Probado en Windows 11 (rutas con tildes y espacios). En Mac queda preparado (Chrome de /Applications), sin probar.
import os, shutil, subprocess, sys, time
from comun import *

OK, MAL = "[OK]", "[FALTA]"
problemas = []


def paso(txt):
    print(f"\n--- {txt}", flush=True)


def ffmpeg_ok():
    paso("ffmpeg y ffprobe")
    for p in ("ffmpeg", "ffprobe"):
        if not tiene(p):
            problemas.append(p)
            print(MAL, p, "no esta instalado.")
            print("   Windows: winget install --id Gyan.FFmpeg -e   (luego cierra y abre la terminal)")
            print("   Mac:     brew install ffmpeg")
            return
    v = run(["ffmpeg", "-version"]).stdout.splitlines()[0]
    print(OK, v[:60])
    filtros = run(["ffmpeg", "-hide_banner", "-filters"]).stdout
    for f in ("afftdn", "loudnorm", "sidechaincompress", "deesser"):
        if f" {f} " not in filtros:
            problemas.append(f"filtro {f}")
            print(MAL, f"tu ffmpeg no trae el filtro {f}. Instala una version 'full'.")


def python_ok():
    paso("Python y librerias (faster-whisper, opencv, numpy)")
    if sys.version_info < (3, 9):
        problemas.append("python")
        print(MAL, "se necesita Python 3.9 o mas nuevo")
        return
    faltan = []
    for mod, pkg in (("faster_whisper", "faster-whisper"), ("cv2", "opencv-python-headless"), ("numpy", "numpy")):
        try:
            __import__(mod)
        except ImportError:
            faltan.append(pkg)
    if faltan:
        print("Instalando para tu usuario:", " ".join(faltan))
        r = subprocess.run([sys.executable, "-m", "pip", "install", "--user", *faltan])
        if r.returncode:
            problemas.append("librerias python")
            print(MAL, "no se pudo instalar:", faltan)
            return
    print(OK, "faster-whisper, opencv y numpy")
    print("Bajando el modelo de voz 'small' (una sola vez, unos 480 MB)...", flush=True)
    try:
        from faster_whisper import WhisperModel
        WhisperModel("small", device="cpu", compute_type="int8")
        print(OK, "modelo small listo")
    except Exception as e:
        problemas.append("modelo whisper")
        print(MAL, "no se pudo bajar el modelo:", e)


def node_ok():
    paso("Node y Remotion")
    if not tiene("node") or not tiene(npm()):
        problemas.append("node")
        print(MAL, "falta Node.js 18 o mas nuevo: https://nodejs.org (instalador normal, sin administrador en Mac/Windows de usuario)")
        return False
    print(OK, "node", run(["node", "-v"]).stdout.strip())
    if os.path.isdir(os.path.join(REMOTION, "node_modules", "remotion")):
        print(OK, "Remotion ya instalado")
        return True
    cmd = [npm(), "ci" if os.path.exists(os.path.join(REMOTION, "package-lock.json")) else "install", "--no-audit", "--no-fund"]
    print("Instalando Remotion dentro del kit (1 o 2 minutos)...", flush=True)
    r = subprocess.run(cmd, cwd=REMOTION)
    if r.returncode:
        problemas.append("npm install")
        print(MAL, "npm fallo. Revisa la conexion y vuelve a correr este instalador.")
        return False
    print(OK, "Remotion instalado")
    return True


def arranca(exe):
    try:
        r = subprocess.run([exe, "--headless", "--disable-gpu", "--dump-dom", "about:blank"], capture_output=True, timeout=40)
        return r.returncode == 0
    except Exception:
        return False


def largo(p):
    """Windows: rutas de mas de 260 letras necesitan el prefijo \\\\?\\ para copiarse."""
    p = os.path.abspath(p)
    return PREFIJO + p if os.name == "nt" and not p.startswith(PREFIJO) else p


PREFIJO = "\\\\?\\"


def navegador_ok():
    paso("Navegador que usa Remotion para dibujar")
    carpeta(TRAB)
    cfg = leer_json(CONFIG_LOCAL, {})
    if cfg.get("navegador") and os.path.exists(cfg["navegador"]) and arranca(cfg["navegador"]):
        print(OK, "ya configurado:", cfg["navegador"])
        return
    cfg.pop("navegador", None)
    subprocess.run([npx(), "remotion", "browser", "ensure"], cwd=REMOTION, capture_output=True, text=True, encoding="utf-8", errors="replace")
    propio = None
    for dp, _, fs in os.walk(largo(os.path.join(REMOTION, "node_modules", ".remotion"))):
        for f in fs:
            if f.startswith("chrome-headless-shell") and (f.endswith(".exe") or "." not in f):
                propio = os.path.join(dp, f)
                propio = propio[4:] if propio.startswith(PREFIJO) else propio
    elegido = None
    if propio:
        if len(propio) < 240 and arranca(propio):
            print(OK, "navegador propio de Remotion")
            escribir_json(CONFIG_LOCAL, cfg)
            return
        # Windows no abre programas en rutas de mas de 260 letras: se copia a una ruta corta del usuario
        corto = os.path.join(os.environ.get("LOCALAPPDATA") or os.path.expanduser("~"), "kit-reels-navegador")
        shutil.rmtree(largo(corto), ignore_errors=True)
        shutil.copytree(largo(os.path.dirname(propio)), largo(corto))
        exe = os.path.join(corto, os.path.basename(propio))
        if arranca(exe):
            elegido = exe
            print(OK, "navegador de Remotion copiado a una ruta corta (la carpeta del kit es muy profunda):", exe)
    if not elegido:
        ch = buscar_chrome()
        if ch and arranca(ch):
            elegido = ch
            print(OK, "se usara el Chrome instalado:", ch)
    if elegido:
        cfg["navegador"] = elegido
    else:
        problemas.append("navegador")
        print(MAL, "no hay navegador que arranque. Instala Google Chrome y vuelve a correr este instalador.")
    escribir_json(CONFIG_LOCAL, cfg)


def prueba_remotion():
    paso("Prueba de Remotion (abre el proyecto y el navegador)")
    cfg = leer_json(CONFIG_LOCAL, {})
    cmd = [npx(), "remotion", "compositions", "src/index.ts"]
    if cfg.get("navegador"):
        cmd.append(f"--browser-executable={cfg['navegador']}")
    r = subprocess.run(cmd, cwd=REMOTION, capture_output=True, text=True, encoding="utf-8", errors="replace")
    if r.returncode or "Reel" not in r.stdout:
        problemas.append("prueba remotion")
        print(MAL, "Remotion no arranco:\n", (r.stderr or r.stdout)[-1500:])
    else:
        print(OK, "Remotion abre el proyecto y encuentra la composicion Reel")


def main():
    t0 = time.time()
    for d in (MATERIAL, MUSICA, BROLL, MARCA_DIR, EXPORT, TRAB):
        carpeta(d)
    ffmpeg_ok()
    python_ok()
    if node_ok():
        navegador_ok()
        prueba_remotion()
    paso("Efectos de sonido")
    if tiene("ffmpeg"):
        import sonidos
        sonidos.crear()
        print(OK, "pop, click, swoosh e impacto en kit/sonidos")
    print(f"\nTiempo: {time.time() - t0:.0f} s")
    if problemas:
        print("\nQUEDO PENDIENTE:", ", ".join(problemas), "\nArregla eso y vuelve a correr: python kit/instalar.py")
        sys.exit(1)
    print("\nTODO LISTO. Pon tus videos en 01-material y abre Claude en esta carpeta.")


if __name__ == "__main__":
    main()
