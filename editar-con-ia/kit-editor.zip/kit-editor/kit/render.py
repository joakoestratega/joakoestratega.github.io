# Paso 5. Aplica la receta y entrega el reel terminado en 05-exportados.
#   base (cortes + color) -> Remotion (zoom, subtitulos, textos) -> mezcla de audio -> MP4 final -> hoja de revision
# Uso: python kit/render.py --receta vende
#      python kit/render.py --receta todas
#      python kit/render.py --receta vende --desde 10 --hasta 14   (prueba rapida de un pedazo)
import json, os, re, shutil, sys, time
import base, sonidos, revisar
from comun import *


def config():
    return leer_json(CONFIG_LOCAL, {})


def mezclar(props, receta, edl, salida):
    a = receta.get("audio", {})
    D = props["duracion"] / FPS
    voz = os.path.join(TRAB, f"voz_{receta['nombre']}.wav")
    ins, filt, etiquetas = ["-i", voz], ["[0:a]aformat=sample_rates=48000:channel_layouts=stereo,asplit=2[vz][sc]"], ["[vz]"]
    # musica
    mus = edl.get("musica") or {}
    archivo = mus.get("archivo") if isinstance(mus, dict) else mus
    if not archivo and os.path.isdir(MUSICA):
        cand = [f for f in sorted(os.listdir(MUSICA)) if f.lower().endswith((".mp3", ".wav", ".m4a", ".aac")) and not sonidos.es_efecto(f)]
        archivo = cand[0] if cand else None
    if archivo and os.path.isfile(os.path.join(MUSICA, archivo)):
        ins += ["-ss", str(mus.get("desde", 0) if isinstance(mus, dict) else 0), "-stream_loop", "-1", "-i", os.path.join(MUSICA, archivo)]
        filt.append(f"[1:a]atrim=0:{D:.3f},asetpts=PTS-STARTPTS,aformat=sample_rates=48000:channel_layouts=stereo,"
                    f"volume={a.get('musica_vol', 0.25)},afade=t=in:d=0.4,afade=t=out:st={max(0, D - 1.2):.3f}:d=1.2[m0]")
        filt.append(f"[m0][sc]sidechaincompress=threshold=0.02:ratio={a.get('ducking_ratio', 6)}:attack=25:release=380:makeup=1[mus]")
        etiquetas.append("[mus]")
    else:
        print("  [AVISO] sin musica: no hay pista en 02-musica")
    # efectos: (cuando, cual)
    sfx = a.get("sfx", {})
    ev = []
    cortes = props["cortes"]
    if "corte" in sfx:
        ev += [(c["desde"] - 0.12, "corte") for c in cortes[1:] if not c["cta"]]
    if "seccion" in sfx:
        ev += [(c["desde"] - 0.25, "seccion") for i, c in enumerate(cortes) if i and c["seccion"] != cortes[i - 1]["seccion"] and not c["cta"]]
    if "gancho" in sfx:
        ev.append((0.02, "gancho"))
    if "fuerte" in sfx:
        ev += [(x[0], "fuerte") for x in props["fuertes"]]
    if "cta" in sfx:
        ev.append((props["cta"]["desde"] + 0.15, "cta"))
    if "tarjeta" in sfx and receta.get("tarjetas"):
        ev += [(t["desde"] - 0.05, "tarjeta") for t in props["tarjetas"]]
    if "item" in sfx and receta.get("tarjetas"):
        ev += [(i["desde"] + 0.1, "item") for t in props["tarjetas"] for i in t["items"]]
    ev = sorted((max(0, t), k) for t, k in ev if t < D)
    # cada efecto entra como archivo propio (simple y sin limites de asplit)
    for n, (t, k) in enumerate(ev):
        ins += ["-i", sonidos.ruta(sfx[k]["son"])]
        idx = sum(1 for x in ins if x == "-i") - 1
        ms = int(t * 1000)
        filt.append(f"[{idx}:a]aformat=sample_rates=48000:channel_layouts=stereo,volume={sfx[k]['vol']},adelay={ms}|{ms}[e{n}]")
        etiquetas.append(f"[e{n}]")
    filt.append("".join(etiquetas) + f"amix=inputs={len(etiquetas)}:normalize=0:duration=longest,atrim=0:{D:.3f},asetpts=PTS-STARTPTS[mx]")
    pre = os.path.join(TRAB, f"mezcla_{receta['nombre']}_pre.wav")
    ffmpeg(*ins, "-filter_complex", ";".join(filt), "-map", "[mx]", "-ar", "48000", "-c:a", "pcm_s24le", pre)
    # volumen final: -14 LUFS, picos -1 dB (dos pasadas)
    r = run(["ffmpeg", "-hide_banner", "-i", pre, "-af", "loudnorm=I=-14:TP=-1.5:LRA=11:print_format=json", "-f", "null", "-"])
    m = json.loads(re.findall(r"\{[^{}]+\}", r.stderr)[-1])
    ln = (f"loudnorm=I=-14:TP=-1.5:LRA=11:measured_I={m['input_i']}:measured_TP={m['input_tp']}:measured_LRA={m['input_lra']}:"
          f"measured_thresh={m['input_thresh']}:offset={m['target_offset']}:linear=true")
    ffmpeg("-i", pre, "-af", f"{ln},aresample=48000,alimiter=limit=0.89:attack=1:release=40:level=false", "-ar", "48000", "-c:a", "pcm_s24le", salida)


def render(nombre, desde=None, hasta=None):
    receta = leer_json(os.path.join(RAIZ, "recetas", nombre + ".json"))
    edl = leer_json(os.path.join(RAIZ, "edl.json"))
    cfg = config()
    libre = shutil.disk_usage(RAIZ).free / 1e9
    if libre < 1.5:
        raise SystemExit(f"[ERROR] Quedan {libre:.1f} GB libres en el disco y el render necesita 1,5 GB. Corre: python kit/limpiar.py")
    inicio = time.time()
    with Cronometro(f"base {nombre}"):
        props = base.construir(nombre)
    with Cronometro(f"remotion {nombre}"):
        vid = os.path.join(TRAB, f"video_{nombre}.mp4")
        props_ruta = os.path.join(PUBLICO, f"props_{nombre}.json")
        cmd = [npx(), "remotion", "render", "src/index.ts", "Reel", vid, f"--props={props_ruta}", f"--public-dir={PUBLICO}",
               "--codec=h264", "--crf=18", "--pixel-format=yuv420p", "--color-space=bt709", "--x264-preset=medium", "--muted", "--log=error",
               f"--concurrency={cfg.get('concurrencia', max(2, (os.cpu_count() or 4) // 2))}"]
        if cfg.get("navegador"):
            cmd.append(f"--browser-executable={cfg['navegador']}")
        if desde is not None:
            cmd.append(f"--frames={fr(desde)}-{min(props['duracion'] - 1, fr(hasta))}")
        r = subprocess.run(cmd, cwd=REMOTION, text=True, encoding="utf-8", errors="replace", capture_output=True)
        if r.returncode:                                     # un fallo suelto del extractor de cuadros: se reintenta con menos hilos
            print("  [AVISO] Remotion fallo, reintento con menos hilos...")
            cmd = [c for c in cmd if not c.startswith("--concurrency")] + ["--concurrency=2"]
            r = subprocess.run(cmd, cwd=REMOTION, text=True, encoding="utf-8", errors="replace", capture_output=True)
        if r.returncode:
            err = "\n".join(l for l in (r.stderr or r.stdout).splitlines() if not l.strip().startswith("at "))
            print(err[:2500])
            raise SystemExit("[ERROR] Remotion fallo. Mira arriba. Si dice que no encuentra el navegador: python kit/instalar.py")
    with Cronometro(f"audio {nombre}"):
        aud = os.path.join(TRAB, f"audio_{nombre}.wav")
        mezclar(props, receta, edl, aud)
    with Cronometro(f"final {nombre}"):
        carpeta(EXPORT)
        titulo = re.sub(r"[^a-zA-Z0-9_-]+", "-", edl.get("titulo", "reel")).strip("-") or "reel"
        if desde is not None:
            out = os.path.join(TRAB, f"prueba_{nombre}.mp4")
            ffmpeg("-i", vid, "-ss", f"{desde:.3f}", "-t", f"{hasta - desde:.3f}", "-i", aud, "-map", "0:v", "-map", "1:a", "-c:v", "copy",
                   "-c:a", "aac", "-b:a", "192k", "-ar", "48000", "-shortest", out)
        else:
            import glob
            hechas = [int(re.findall(r"_v(\d+)\.mp4$", f)[0]) for f in glob.glob(os.path.join(EXPORT, f"{titulo}_{nombre}_v*.mp4"))
                      if re.findall(r"_v(\d+)\.mp4$", f)]
            v = max(hechas, default=0) + 1                   # siempre una version nueva, nunca reusa un numero
            out = os.path.join(EXPORT, f"{titulo}_{nombre}_v{v}.mp4")
            ffmpeg("-i", vid, "-i", aud, "-map", "0:v", "-map", "1:a", "-c:v", "copy", "-c:a", "aac", "-b:a", "192k", "-ar", "48000",
                   "-movflags", "+faststart", "-shortest", out)
    import limpiar
    for x in (vid, os.path.join(PUBLICO, f"base_{nombre}.mp4"), os.path.join(TRAB, f"mezcla_{nombre}_pre.wav")):
        if desde is None and os.path.exists(x):
            os.remove(x)                                     # intermedios grandes: el final ya los tiene adentro
    for x in limpiar.temporales_remotion():                  # temporales que dejo ESTE render en la carpeta Temp
        if os.path.getmtime(x) >= inicio - 5:
            shutil.rmtree(x, ignore_errors=True)
    print(f"LISTO: {out}")
    if desde is None:
        revisar.revisar(out, nombre)
    return out


if __name__ == "__main__":
    if "--receta" not in sys.argv:
        raise SystemExit("Uso: python kit/render.py --receta vende|cine|premium|explicador|todas")
    r = sys.argv[sys.argv.index("--receta") + 1]
    d = float(sys.argv[sys.argv.index("--desde") + 1]) if "--desde" in sys.argv else None
    h = float(sys.argv[sys.argv.index("--hasta") + 1]) if "--hasta" in sys.argv else None
    lista = [f[:-5] for f in sorted(os.listdir(os.path.join(RAIZ, "recetas"))) if f.endswith(".json")] if r == "todas" else [r]
    for x in lista:
        t0 = time.time()
        render(x, d, h)
        print(f"== TOTAL {x}: {time.time() - t0:.1f} s")
