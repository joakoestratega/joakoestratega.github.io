# Funciones compartidas del kit. Todo en UTF-8 y con rutas que aguantan tildes y espacios.
import json, os, shutil, subprocess, sys, time, unicodedata, re

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")

FPS = 30
W, H = 1080, 1920
KIT = os.path.dirname(os.path.abspath(__file__))
RAIZ = os.path.dirname(KIT)
MATERIAL = os.path.join(RAIZ, "01-material")
MUSICA = os.path.join(RAIZ, "02-musica")
BROLL = os.path.join(RAIZ, "03-broll")
MARCA_DIR = os.path.join(RAIZ, "04-marca")
EXPORT = os.path.join(RAIZ, "05-exportados")
TRAB = os.path.join(RAIZ, "_trabajo")
TOMAS = os.path.join(TRAB, "tomas")          # versiones de trabajo 1080x1920
VOCES = os.path.join(TRAB, "voces")          # voz limpia por toma (48 kHz)
WAV16 = os.path.join(TRAB, "wav16")          # audio para transcribir
PUBLICO = os.path.join(TRAB, "render")       # carpeta publica de Remotion
REMOTION = os.path.join(RAIZ, "remotion")
SONIDOS = os.path.join(KIT, "sonidos")
CONFIG_LOCAL = os.path.join(TRAB, "config-local.json")
VIDEO_EXT = (".mov", ".mp4", ".m4v", ".mkv", ".avi", ".mts")


def carpeta(*p):
    d = os.path.join(*p)
    os.makedirs(d, exist_ok=True)
    return d


def leer_json(ruta, defecto=None):
    if not os.path.exists(ruta):
        if defecto is not None:
            return defecto
        raise SystemExit(f"[ERROR] No existe {ruta}")
    with open(ruta, encoding="utf-8-sig") as f:
        return json.load(f)


def escribir_json(ruta, datos):
    with open(ruta, "w", encoding="utf-8") as f:
        json.dump(datos, f, ensure_ascii=False, indent=1)


def run(cmd, ok=True, cwd=None):
    r = subprocess.run(cmd, capture_output=True, text=True, encoding="utf-8", errors="replace", cwd=cwd)
    if ok and r.returncode:
        print("[ERROR] fallo:", " ".join(str(c) for c in cmd[:6]), "...")
        print(r.stderr[-3000:] or r.stdout[-3000:])
        raise SystemExit(1)
    return r


def ffmpeg(*args):
    return run(["ffmpeg", "-hide_banner", "-v", "error", "-y", *args])


def duracion(ruta):
    r = run(["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "csv=p=0", ruta])
    return float(r.stdout.strip())


def fr(t):
    return int(round(t * FPS))


def norm(txt):
    """minusculas, sin tildes, sin signos: para comparar palabras."""
    t = unicodedata.normalize("NFD", str(txt).lower())
    t = "".join(c for c in t if unicodedata.category(c) != "Mn")
    return re.sub(r"[^a-z0-9ñ$%]", "", t)


def tomas_material():
    if not os.path.isdir(MATERIAL):
        raise SystemExit("[ERROR] Falta la carpeta 01-material")
    return sorted(f for f in os.listdir(MATERIAL) if f.lower().endswith(VIDEO_EXT))


def nombre_toma(archivo):
    return os.path.splitext(os.path.basename(archivo))[0]


class Cronometro:
    def __init__(self, fase):
        self.fase, self.t0 = fase, time.time()

    def __enter__(self):
        print(f"== {self.fase} ...", flush=True)
        return self

    def __exit__(self, *a):
        dt = time.time() - self.t0
        print(f"== {self.fase}: {dt:.1f} s", flush=True)
        reg = leer_json(os.path.join(TRAB, "tiempos.json"), {}) if os.path.isdir(TRAB) else {}
        reg[self.fase] = round(dt, 1)
        if os.path.isdir(TRAB):
            escribir_json(os.path.join(TRAB, "tiempos.json"), reg)


def npx():
    return "npx.cmd" if os.name == "nt" else "npx"


def npm():
    return "npm.cmd" if os.name == "nt" else "npm"


def buscar_chrome():
    cands = []
    if os.name == "nt":
        for base in (os.environ.get("PROGRAMFILES", r"C:\Program Files"), os.environ.get("PROGRAMFILES(X86)", r"C:\Program Files (x86)"),
                     os.environ.get("LOCALAPPDATA", "")):
            cands += [os.path.join(base, "Google", "Chrome", "Application", "chrome.exe"),
                      os.path.join(base, "Microsoft", "Edge", "Application", "msedge.exe")]
    else:
        cands += ["/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
                  "/Applications/Chromium.app/Contents/MacOS/Chromium",
                  "/usr/bin/google-chrome", "/usr/bin/chromium", "/usr/bin/chromium-browser"]
    for c in cands:
        if c and os.path.exists(c):
            return c
    return None


def tiene(prog):
    return shutil.which(prog) is not None
