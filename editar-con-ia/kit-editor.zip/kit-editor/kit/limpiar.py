# Libera espacio. Uso:
#   python kit/limpiar.py            borra intermedios de render y temporales de Remotion
#   python kit/limpiar.py --todo     ademas borra _trabajo completo y la copia del navegador (luego: python kit/instalar.py)
# Nunca toca 01-material, 02-musica, 03-broll, 04-marca ni 05-exportados.
import glob, os, shutil, sys, tempfile
from comun import *


def peso(ruta):
    if os.path.isfile(ruta):
        return os.path.getsize(ruta)
    total = 0
    for dp, _, fs in os.walk(ruta):
        for f in fs:
            try:
                total += os.path.getsize(os.path.join(dp, f))
            except OSError:
                pass
    return total


def borrar(ruta, liberado):
    if not os.path.exists(ruta):
        return liberado
    b = peso(ruta)
    if os.path.isdir(ruta):
        shutil.rmtree(ruta, ignore_errors=True)
    else:
        try:
            os.remove(ruta)
        except OSError:
            return liberado
    print(f"  borrado {ruta} ({b / 1e6:.0f} MB)")
    return liberado + b


def temporales_remotion():
    tmp = tempfile.gettempdir()
    return [p for pat in ("remotion-v*-assets*", "remotion-webpack-bundle-*") for p in glob.glob(os.path.join(tmp, pat))]


def intermedios():
    rutas = [os.path.join(TRAB, "segmentos")]
    rutas += glob.glob(os.path.join(PUBLICO, "base_*.mp4"))
    rutas += glob.glob(os.path.join(TRAB, "video_*.mp4")) + glob.glob(os.path.join(TRAB, "mezcla_*_pre.wav"))
    rutas += glob.glob(os.path.join(TRAB, "prueba_*.mp4"))
    return rutas


def main():
    todo = "--todo" in sys.argv
    liberado = 0
    for r in intermedios() + temporales_remotion():
        liberado = borrar(r, liberado)
    if todo:
        cfg = leer_json(CONFIG_LOCAL, {})
        nav = cfg.get("navegador", "")
        copia = os.path.join(os.environ.get("LOCALAPPDATA") or os.path.expanduser("~"), "kit-reels-navegador")
        if nav.startswith(copia) or os.path.isdir(copia):
            liberado = borrar(copia, liberado)
        liberado = borrar(TRAB, liberado)
        print("  Para volver a renderizar: python kit/instalar.py y luego desde preparar.")
    print(f"Listo: {liberado / 1e9:.2f} GB liberados. Libres ahora: {shutil.disk_usage(RAIZ).free / 1e9:.1f} GB")


if __name__ == "__main__":
    main()
