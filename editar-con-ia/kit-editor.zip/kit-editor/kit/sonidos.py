# Efectos de sonido. Si en 02-musica hay un archivo con "swoosh", "whoosh", "impact", "pop" o "click" en el nombre,
# se usa ese. Si no, se usa el que el kit fabrica con ffmpeg (sin voz, sin IA).
import os
from comun import *

RECETAS_SON = {
    "pop": "aevalsrc='0.9*sin(2*PI*(260+700*exp(-38*t))*t)*exp(-26*t)':s=48000:d=0.18",
    "click": "aevalsrc='0.8*sin(2*PI*2400*t)*exp(-140*t)+0.5*sin(2*PI*900*t)*exp(-90*t)':s=48000:d=0.06",
    "swoosh": "anoisesrc=d=0.5:c=pink:r=48000:a=0.9,bandpass=f=1800:w=1.4,afade=t=in:d=0.3:curve=exp,afade=t=out:st=0.3:d=0.2",
    "impacto": "aevalsrc='0.95*sin(2*PI*(42+90*exp(-9*t))*t)*exp(-2.8*t)':s=48000:d=1.4,lowpass=f=900",
}
CLAVES = {"swoosh": ("swoosh", "whoosh"), "impacto": ("impact", "boom", "hit"), "pop": ("pop",), "click": ("click", "tick")}


def crear():
    carpeta(SONIDOS)
    for n, src in RECETAS_SON.items():
        out = os.path.join(SONIDOS, n + ".wav")
        if not os.path.exists(out):
            ffmpeg("-f", "lavfi", "-i", src, "-ac", "1", out)


def ruta(nombre):
    if os.path.isdir(MUSICA):
        for f in sorted(os.listdir(MUSICA)):
            fl = f.lower()
            if any(k in fl for k in CLAVES.get(nombre, ())) and not (nombre == "swoosh" and "impact" in fl):
                return os.path.join(MUSICA, f)
    crear()
    return os.path.join(SONIDOS, nombre + ".wav")


def es_efecto(archivo):
    fl = archivo.lower()
    return any(k in fl for v in CLAVES.values() for k in v)
