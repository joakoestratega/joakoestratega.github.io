# Paso 6. Revisa un video: hoja de fotogramas cada 1,5 s, volumen medido y subtitulos sospechosos.
# Uso: python kit/revisar.py 05-exportados/mi-reel_vende_v1.mp4 [receta]
import json, os, re, subprocess, sys
import numpy as np
from comun import *



def revisar_subtitulos(props):
    """Marca lineas que terminan en palabra debil, cambios de tamano y pantallas apretadas o muy anchas."""
    from base import DURAS, SUAVES, deb
    grupos = props.get("grupos", [])
    problemas = []
    for i, g in enumerate(grupos):
        for li, ln in enumerate(g.get("lineas") or [list(range(len(g["palabras"])))]):
            ultima = deb(g["palabras"][ln[-1]]["t"])
            es_final = i == len(grupos) - 1 or (li == len(g.get("lineas", [0])) - 1 and grupos[i + 1]["desde"] - g["hasta"] > 0.3)
            if not es_final and (ultima in DURAS or (ultima in SUAVES)):
                tipo = "DEBIL" if ultima in DURAS else "debil suave"
                texto = " / ".join(" ".join(g["palabras"][k]["t"] for k in l) for l in (g.get("lineas") or [ln]))
                problemas.append(f"{g['desde']:6.2f}s  {tipo:11} '{ultima}' en: {texto}")
        if i and g.get("tam") != grupos[i - 1].get("tam"):
            problemas.append(f"{g['desde']:6.2f}s  TAMANO      cambia de {grupos[i - 1].get('tam')} a {g.get('tam')} px")
        if g.get("nota"):
            problemas.append(f"{g['desde']:6.2f}s  {g['nota']:11} zona {g['zona']}, {g['alto']} px libres")
    print("  Subtitulos:", "sin problemas" if not problemas else f"{len(problemas)} para mirar")
    for x in problemas:
        print("   ", x)
    return problemas


def hoja(video, salida, cada=1.5, ancho=270):
    import cv2
    dur = duracion(video)
    alto = int(ancho * 16 / 9)
    cuadros, t = [], 0.2
    while t < dur:
        r = subprocess.run(["ffmpeg", "-v", "error", "-ss", f"{t:.2f}", "-i", video, "-frames:v", "1", "-vf", f"scale={ancho}:{alto}",
                            "-f", "rawvideo", "-pix_fmt", "bgr24", "-"], capture_output=True)
        if len(r.stdout) == ancho * alto * 3:
            img = np.frombuffer(r.stdout, np.uint8).reshape(alto, ancho, 3).copy()
            cv2.rectangle(img, (0, 0), (78, 30), (0, 0, 0), -1)
            cv2.putText(img, f"{t:.1f}s", (5, 22), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 180, 248), 2)
            cuadros.append(img)
        t += cada
    cols = 7
    while len(cuadros) % cols:
        cuadros.append(np.zeros_like(cuadros[0]))
    filas = [np.hstack(cuadros[i:i + cols]) for i in range(0, len(cuadros), cols)]
    ok, b = cv2.imencode(".jpg", np.vstack(filas), [cv2.IMWRITE_JPEG_QUALITY, 82])
    with open(salida, "wb") as f:      # escritura por Python: aguanta tildes en la ruta
        f.write(b.tobytes())


def volumen(video):
    r = run(["ffmpeg", "-hide_banner", "-i", video, "-af", "ebur128=peak=true", "-f", "null", "-"])
    txt = r.stderr[r.stderr.rfind("Summary"):]
    i = re.search(r"I:\s+(-?[\d.]+) LUFS", txt)
    p = re.search(r"Peak:\s+(-?[\d.]+) dBFS", txt)
    return float(i.group(1)) if i else None, float(p.group(1)) if p else None


def revisar(video, receta=None):
    receta = receta or (os.path.basename(video).rsplit("_", 2)[-2] if "_" in os.path.basename(video) else None)
    salida = os.path.splitext(video)[0] + "_hoja.jpg"
    with Cronometro("revisar"):
        hoja(video, salida)
        lufs, pico = volumen(video)
        info = run(["ffprobe", "-v", "error", "-show_entries", "stream=codec_name,width,height,r_frame_rate,pix_fmt,sample_rate",
                    "-of", "compact=p=0:nk=1", video]).stdout.strip().replace("\n", " | ")
    print(f"  Archivo: {video}\n  Duracion: {duracion(video):.1f} s | {info}")
    print(f"  Volumen: {lufs} LUFS (meta -14) | pico real {pico} dBTP (meta <= -1)")
    if lufs is not None and abs(lufs + 14) > 1:
        print("  [AVISO] el volumen se salio de -14 LUFS")
    if pico is not None and pico > -0.9:
        print("  [AVISO] el pico pasa de -1 dB")
    props = os.path.join(PUBLICO, f"props_{receta}.json") if receta else None
    if props and os.path.exists(props):
        revisar_subtitulos(leer_json(props))
    print(f"  Hoja de fotogramas: {salida}  (abrela y mira: caras, estampado, frases, letra)")
    return salida


if __name__ == "__main__":
    if len(sys.argv) < 2:
        raise SystemExit("Uso: python kit/revisar.py ruta-del-video.mp4 [receta]")
    revisar(sys.argv[1], sys.argv[2] if len(sys.argv) > 2 else None)
