# Paso 2. Transcribe cada toma con faster-whisper (modelo small, CPU) con tiempo por palabra.
# Sin initial_prompt: ese texto hace que Whisper se coma el comienzo de las tomas.
# Uso: python kit/transcribir.py [--modelo small] [--rehacer]
import os, sys
from comun import *


def main():
    modelo = sys.argv[sys.argv.index("--modelo") + 1] if "--modelo" in sys.argv else "small"
    salida = os.path.join(TRAB, "transcripcion.json")
    previo = leer_json(salida, {}) if "--rehacer" not in sys.argv else {}
    wavs = sorted(f for f in os.listdir(WAV16) if f.endswith(".wav")) if os.path.isdir(WAV16) else []
    if not wavs:
        raise SystemExit("[ERROR] No hay audio preparado. Corre primero: python kit/preparar.py")
    pendientes = [f for f in wavs if f[:-4] not in previo]
    with Cronometro("transcribir"):
        if pendientes:
            from faster_whisper import WhisperModel
            m = WhisperModel(modelo, device="cpu", compute_type="int8", cpu_threads=os.cpu_count() or 4)
            for f in pendientes:
                segs, _ = m.transcribe(os.path.join(WAV16, f), language="es", word_timestamps=True,
                                       vad_filter=False, condition_on_previous_text=False, beam_size=5)
                palabras = []
                for s in segs:
                    for w in s.words or []:
                        txt = w.word.strip()
                        if txt:
                            palabras.append({"w": txt, "s": round(w.start, 2), "e": round(w.end, 2), "p": round(w.probability, 2)})
                previo[f[:-4]] = palabras
                print(f"  {f[:-4]}: {len(palabras)} palabras", flush=True)
        escribir_json(salida, previo)
    # version para leer: frases con tiempos y cada palabra con su inicio
    lineas = ["# Transcripcion por toma", "",
              "Formato: [inicio-fin] frase. Debajo, cada palabra con su segundo de inicio y fin.", ""]
    for toma, pal in previo.items():
        lineas.append(f"## {toma}")
        frase = []
        for i, p in enumerate(pal):
            frase.append(p)
            fin = p["w"][-1] in ".?!" or i == len(pal) - 1 or pal[i + 1]["s"] - p["e"] > 0.6
            if fin:
                txt = " ".join(x["w"] for x in frase)
                lineas.append(f"- [{frase[0]['s']:.2f}-{frase[-1]['e']:.2f}] {txt}")
                lineas.append("  " + " ".join(f"{x['w']}({x['s']:.2f}-{x['e']:.2f})" for x in frase))
                frase = []
        lineas.append("")
    with open(os.path.join(TRAB, "transcripcion.md"), "w", encoding="utf-8") as f:
        f.write("\n".join(lineas))
    print("Listo: _trabajo/transcripcion.md. Sigue: escribir edl.json y correr python kit/base.py")


if __name__ == "__main__":
    main()
