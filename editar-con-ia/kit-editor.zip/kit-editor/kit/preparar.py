# Paso 1. Deja cada toma lista para editar:
#  - video de trabajo 1080x1920, 30 cuadros, rotacion corregida, SDR
#  - voz limpia (ruido, EQ suave, compresion) a 48 kHz
#  - audio de 16 kHz para transcribir
#  - posicion de la cara y del estampado de la camiseta (para zoom y subtitulos)
# Uso: python kit/preparar.py            (solo procesa lo que falte)
#      python kit/preparar.py --rehacer  (todo de nuevo)
import os, sys
from concurrent.futures import ThreadPoolExecutor
from comun import *

REHACER = "--rehacer" in sys.argv

VOZ_FILTRO = ("highpass=f=80,afftdn=nf=-30:tn=1,"
              "equalizer=f=200:t=q:w=1.2:g=-2,equalizer=f=3200:t=q:w=1:g=2.5,equalizer=f=9500:t=q:w=1:g=1.5,"
              "deesser=i=0.35,acompressor=threshold=-24dB:ratio=3:attack=6:release=120:makeup=5dB,"
              "alimiter=limit=0.9:level=false")


def es_hdr(ruta):
    r = run(["ffprobe", "-v", "error", "-select_streams", "v:0", "-show_entries", "stream=color_transfer",
             "-of", "csv=p=0", ruta], ok=False)
    return r.stdout.strip() in ("arib-std-b67", "smpte2084")


def preparar_toma(archivo):
    src = os.path.join(MATERIAL, archivo)
    n = nombre_toma(archivo)
    vid, voz, w16 = os.path.join(TOMAS, n + ".mp4"), os.path.join(VOCES, n + ".wav"), os.path.join(WAV16, n + ".wav")
    if REHACER or not os.path.exists(vid):
        tm = ("zscale=t=linear:npl=100,format=gbrpf32le,zscale=p=bt709,tonemap=hable:desat=0,"
              "zscale=t=bt709:m=bt709:r=tv,format=yuv420p," if es_hdr(src) else "")
        # escala y recorta al centro para que cualquier toma (horizontal o vertical) quede 1080x1920
        vf = (tm + f"scale={W}:{H}:force_original_aspect_ratio=increase:flags=lanczos,crop={W}:{H},"
              f"setsar=1,fps={FPS},format=yuv420p")
        ffmpeg("-i", src, "-vf", vf, "-an", "-c:v", "libx264", "-preset", "veryfast", "-crf", "15",
               "-g", "15", "-movflags", "+faststart", vid + ".tmp.mp4")
        os.replace(vid + ".tmp.mp4", vid)
    if REHACER or not os.path.exists(voz):
        ffmpeg("-i", src, "-vn", "-af", VOZ_FILTRO, "-ar", "48000", "-ac", "1", voz)
    if REHACER or not os.path.exists(w16):
        ffmpeg("-i", src, "-vn", "-ar", "16000", "-ac", "1", w16)
    return n


HSV = leer_json(os.path.join(RAIZ, "marca.json"), {}).get("estampado_hsv", [[17, 150, 150], [34, 255, 255]])


def detectar(n):
    """Cara (Haar de OpenCV) y estampado del pecho (pixeles amarillos o blancos bajo la cara)."""
    import cv2, numpy as np
    # OpenCV no abre rutas con tildes en Windows: el modelo se carga desde memoria y los cuadros salen por ffmpeg
    with open(os.path.join(cv2.data.haarcascades, "haarcascade_frontalface_default.xml"), encoding="utf-8") as fx:
        fs = cv2.FileStorage(fx.read(), cv2.FILE_STORAGE_READ | cv2.FILE_STORAGE_MEMORY)
    casc = cv2.CascadeClassifier()
    casc.read(fs.getFirstTopLevelNode())
    ruta = os.path.join(TOMAS, n + ".mp4")
    dur = duracion(ruta)
    caras, logos = [], []
    for k in range(8):
        r = subprocess.run(["ffmpeg", "-v", "error", "-ss", f"{dur * (k + 0.5) / 8:.2f}", "-i", ruta, "-frames:v", "1",
                            "-f", "rawvideo", "-pix_fmt", "bgr24", "-"], capture_output=True)
        if len(r.stdout) != W * H * 3:
            continue
        img = np.frombuffer(r.stdout, np.uint8).reshape(H, W, 3)
        g = cv2.cvtColor(cv2.resize(img, (540, 960)), cv2.COLOR_BGR2GRAY)
        f = casc.detectMultiScale(g, 1.1, 6, minSize=(70, 70))
        if len(f) == 0:
            continue
        x, y, w, h = [v * 2 for v in max(f, key=lambda r: r[2] * r[3])]
        caras.append((x, y, w, h))
        # estampado: zona del pecho, desde la barbilla hasta 4 alturas de cara mas abajo
        y0, y1 = int(y + h * 1.25), int(min(H, y + h * 5))
        x0, x1 = int(max(0, x - w * 1.6)), int(min(W, x + w * 2.6))
        hsv = cv2.cvtColor(img[y0:y1, x0:x1], cv2.COLOR_BGR2HSV)
        # color vivo del estampado (marca.json > estampado_hsv). Piel, madera y papel no entran
        m = cv2.inRange(hsv, tuple(HSV[0]), tuple(HSV[1]))
        m = cv2.morphologyEx(m, cv2.MORPH_CLOSE, np.ones((21, 21), np.uint8))
        cnt, _ = cv2.findContours(m, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        cnt = [c for c in cnt if cv2.contourArea(c) > 1500]
        if cnt:
            c0 = max(cnt, key=cv2.contourArea)
            bx, by, bw, bh = cv2.boundingRect(c0)
            # el texto blanco del logo suele ir encima del color: se amplia hacia arriba
            ext = int(bh * 1.5)
            logos.append((bx + x0 - 30, by + y0 - ext, bw + 60, bh + ext + 30))
    med = lambda L: [int(sorted(v)[len(v) // 2]) for v in zip(*L)] if L else None
    c = med(caras) or [W // 2 - 150, int(H * 0.30), 300, 300]   # sin cara: centro arriba
    return {"cara": {"x": c[0], "y": c[1], "w": c[2], "h": c[3], "cx": c[0] + c[2] // 2, "cy": c[1] + c[3] // 2,
                     "detectada": bool(caras)},
            "estampado": estampado(logos)}


def estampado(logos):
    """Caja del estampado: se toma de los puntos mas altos entre las muestras (la persona se mueve)."""
    if not logos:
        return None
    tops = sorted(l[1] for l in logos)
    top = tops[1] if len(tops) >= 4 else tops[0]        # el segundo mas alto: aguanta un dato raro
    bottom = sorted(l[1] + l[3] for l in logos)[len(logos) // 2]
    x0 = min(l[0] for l in logos); x1 = max(l[0] + l[2] for l in logos)
    return {"x": x0, "y": top, "w": x1 - x0, "h": bottom - top}


def main():
    for d in (TRAB, TOMAS, VOCES, WAV16, PUBLICO):
        carpeta(d)
    tomas = tomas_material()
    if not tomas:
        raise SystemExit("[ERROR] 01-material esta vacia")
    with Cronometro("preparar"):
        with ThreadPoolExecutor(3) as ex:
            nombres = list(ex.map(preparar_toma, tomas))
        info = {}
        for n in nombres:
            info[n] = detectar(n)
            info[n]["duracion"] = round(duracion(os.path.join(TOMAS, n + ".mp4")), 3)
            c, e = info[n]["cara"], info[n]["estampado"]
            print(f"  {n}: {info[n]['duracion']} s | cara {'ok' if c['detectada'] else 'NO DETECTADA'} "
                  f"y={c['y']}-{c['y'] + c['h']} | estampado {('y=%d-%d' % (e['y'], e['y'] + e['h'])) if e else 'no'}")
        escribir_json(os.path.join(TRAB, "tomas.json"), info)
    print("Listo. Sigue: python kit/transcribir.py")


if __name__ == "__main__":
    main()
