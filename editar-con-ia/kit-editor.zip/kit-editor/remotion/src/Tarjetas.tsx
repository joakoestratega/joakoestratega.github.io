import React from 'react';
import {interpolate, useCurrentFrame, useVideoConfig} from 'remotion';
import {Props, ajustar, clamp, colores, entrada, familia, suave} from './util';

// Chulo y equis dibujados con trazo (no dependen de que la fuente tenga el caracter)
export const Marca: React.FC<{tipo: string; e: number; tam?: number; p: Props}> = ({tipo, e, tam = 64, p}) => {
  const col = colores(p);
  const anillo = suave(e, 0, 8);
  const t1 = suave(e, 4, 11), t2 = suave(e, 9, 16);
  const ok = tipo === 'chulo';
  return (
    <svg width={tam} height={tam} viewBox="0 0 64 64" style={{flexShrink: 0}}>
      <circle cx={32} cy={32} r={29} fill={ok ? col.acento : 'none'} stroke={ok ? col.acento : col.texto} strokeWidth={3}
        strokeDasharray={183} strokeDashoffset={183 * (1 - anillo)} opacity={ok ? 1 : 0.9} />
      {ok ? (
        <path d="M18 33 L28 43 L47 22" fill="none" stroke={col.fondo} strokeWidth={6} strokeLinecap="round" strokeLinejoin="round"
          strokeDasharray={45} strokeDashoffset={45 * (1 - suave(e, 5, 15))} />
      ) : (
        <>
          <path d="M21 21 L43 43" stroke={col.texto} strokeWidth={6} strokeLinecap="round" strokeDasharray={32} strokeDashoffset={32 * (1 - t1)} />
          <path d="M43 21 L21 43" stroke={col.texto} strokeWidth={6} strokeLinecap="round" strokeDasharray={32} strokeDashoffset={32 * (1 - t2)} />
        </>
      )}
    </svg>
  );
};

export const Tarjetas: React.FC<{p: Props; zona: [number, number]}> = ({p, zona}) => {
  const f = useCurrentFrame();
  const {fps} = useVideoConfig();
  const t = f / fps;
  const col = colores(p);
  const fam = familia(p);
  if (!p.receta.tarjetas) return null;
  const tj = p.tarjetas.find((x: any) => t >= x.desde && t < x.hasta);
  if (!tj) return null;
  const e = f - Math.round(tj.desde * fps);
  const sal = interpolate(t, [tj.hasta - 0.2, tj.hasta], [1, 0], clamp);
  const s = entrada(e, fps, 0, {damping: 15, stiffness: 190});
  const [z0, z1] = zona;
  const alto = z1 - z0;
  const marco: React.CSSProperties = {position: 'absolute', left: 90, right: 90, top: z0, height: alto, display: 'flex', flexDirection: 'column',
    justifyContent: 'center', opacity: sal * s, transform: `translateY(${(1 - s) * 30}px)`};
  const titulo = tj.titulo && (
    <div style={{fontFamily: fam, fontWeight: 800, fontSize: 40, letterSpacing: 6, color: col.acento, textTransform: 'uppercase', marginBottom: 14}}>{tj.titulo}</div>
  );

  if (tj.tipo === 'lista') {
    const n = tj.items.length;
    const fila = Math.min(104, (alto - 130) / Math.max(1, n));
    return (
      <div style={marco}>
        {titulo}
        {tj.items.map((it: any, i: number) => {
          const ei = f - Math.round(it.desde * fps);
          if (ei < 0) return <div key={i} style={{height: fila}} />;
          const si = entrada(ei, fps, 0, {damping: 14, stiffness: 220});
          const tachar = it.marca === 'equis' ? suave(ei, 12, 22) : 0;
          return (
            <div key={i} style={{height: fila, display: 'flex', alignItems: 'center', gap: 26, transform: `translateX(${(1 - si) * -60}px)`, opacity: si}}>
              <Marca tipo={it.marca} e={ei} tam={fila * 0.72} p={p} />
              <div style={{position: 'relative', fontFamily: fam, fontWeight: 800, fontSize: ajustar(it.texto, fila * 0.62, 800, 720, fila, 0, fam),
                color: col.texto, opacity: it.marca === 'equis' ? 1 - tachar * 0.35 : 1}}>
                {it.texto}
                <div style={{position: 'absolute', left: -4, top: '54%', height: 5, borderRadius: 3, width: `calc(${tachar * 100}% + 8px)`, background: col.acento}} />
              </div>
            </div>
          );
        })}
      </div>
    );
  }
  if (tj.tipo === 'comparacion') {
    return (
      <div style={marco}>
        {titulo}
        <div style={{display: 'flex', gap: 28}}>
          {tj.items.map((it: any, i: number) => {
            const ei = f - Math.round(it.desde * fps);
            const si = ei < 0 ? 0 : entrada(ei, fps, 0, {damping: 13, stiffness: 210});
            const ok = it.marca === 'chulo';
            return (
              <div key={i} style={{flex: 1, height: alto - 180, borderRadius: 28, background: ok ? col.acento : '#ffffff14', border: `3px solid ${ok ? col.acento : '#ffffff40'}`,
                display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 20, opacity: si, transform: `scale(${interpolate(si, [0, 1], [0.8, 1])})`}}>
                {ei >= 0 && <Marca tipo={it.marca} e={ei} tam={78} p={{...p, marca: {...p.marca, colores: ok ? {fondo: col.acento, acento: col.fondo, texto: col.fondo} : p.marca?.colores}}} />}
                <div style={{fontFamily: fam, fontWeight: 800, fontSize: ajustar(it.texto, 54, 800, 700, 130, 0, fam), color: ok ? col.fondo : col.texto, textAlign: 'center', padding: '0 16px'}}>{it.texto}</div>
              </div>
            );
          })}
        </div>
      </div>
    );
  }
  // frase
  return (
    <div style={{...marco, alignItems: 'center'}}>
      <div style={{display: 'flex', alignItems: 'center', gap: 30, background: '#ffffff10', border: `3px solid ${col.acento}`, borderRadius: 30, padding: '36px 44px'}}>
        <Marca tipo={tj.marca || 'chulo'} e={e} tam={96} p={p} />
        <div style={{fontFamily: fam, fontWeight: 900, fontSize: ajustar(tj.texto, 76, 900, 1400, 190, -1, fam), lineHeight: 1.1, color: col.texto, maxWidth: 720}}>{tj.texto}</div>
      </div>
    </div>
  );
};

// Palabra clave en grande cuando el panel no tiene tarjeta
export const Destacado: React.FC<{p: Props; zona: [number, number]}> = ({p, zona}) => {
  const f = useCurrentFrame();
  const {fps} = useVideoConfig();
  const t = f / fps;
  const col = colores(p);
  const fam = familia(p);
  if (t < p.gancho.hasta || t >= p.cta.desde) return null;
  if (p.tarjetas.some((x: any) => t >= x.desde - 0.1 && t < x.hasta + 0.1)) return null;
  const claves = p.grupos.flatMap((g: any) => g.palabras.filter((w: any) => w.clave));
  const w = [...claves].reverse().find((x: any) => x.desde <= t);
  if (!w) return null;
  const e = f - Math.round(w.desde * fps);
  const s = entrada(e, fps, 0, {damping: 12, stiffness: 230});
  const txt = w.t.toUpperCase();
  const [z0, z1] = zona;
  return (
    <div style={{position: 'absolute', left: 40, right: 40, top: z0, height: z1 - z0, display: 'flex', alignItems: 'center', justifyContent: 'center'}}>
      <div style={{textAlign: 'center', transform: `scale(${interpolate(s, [0, 1], [0.6, 1])})`, opacity: s}}>
        <div style={{fontFamily: fam, fontWeight: 900, fontSize: ajustar(txt, 150, 900, 960, z1 - z0 - 60, -3, fam), letterSpacing: -3, color: col.acento, lineHeight: 1}}>{txt}</div>
        <div style={{height: 8, borderRadius: 4, background: col.texto, width: `${suave(e, 4, 16) * 100}%`, marginTop: 16}} />
      </div>
    </div>
  );
};
