import React from 'react';
import {Img, interpolate, staticFile, useCurrentFrame, useVideoConfig} from 'remotion';
import {Props, ajustar, clamp, colores, entrada, familia, partirCta, suave} from './util';

// ---------- Gancho: texto grande de los primeros segundos ----------
export const Gancho: React.FC<{p: Props}> = ({p}) => {
  const f = useCurrentFrame();
  const {fps} = useVideoConfig();
  const col = colores(p);
  const fam = familia(p);
  const g = p.gancho;
  const fin = Math.round(g.hasta * fps);
  if (!g.texto || f > fin) return null;
  const estilo = p.receta.gancho.estilo;
  const [z0, z1] = g.zona;
  const alto = Math.max(90, z1 - z0);
  const sal = interpolate(f, [fin - 6, fin], [1, 0], clamp);
  const caja = (hijos: React.ReactNode, extra: React.CSSProperties = {}) => (
    <div style={{position: 'absolute', left: 50, right: 50, top: z0, height: alto, display: 'flex', alignItems: 'center', justifyContent: 'center', opacity: sal, ...extra}}>{hijos}</div>
  );
  if (estilo === 'caja') {
    const txt = g.texto.toUpperCase();
    const tam = ajustar(txt, 84, 900, 880, alto - 40, -1, fam);
    const s = entrada(f, fps, 1, {damping: 9, stiffness: 240, mass: 0.6});
    const temblor = f < 10 ? Math.sin(f * 2.4) * (10 - f) * 0.5 : 0;
    return caja(
      <div style={{background: col.acento, padding: `${tam * 0.16}px ${tam * 0.4}px`, borderRadius: 16, boxShadow: '0 14px 34px rgba(0,0,0,.5)',
        transform: `scale(${interpolate(s, [0, 1], [0.3, 1])}) rotate(${-2.5 + temblor * 0.2}deg) translateX(${temblor}px)`}}>
        <span style={{fontFamily: fam, fontWeight: 900, fontSize: tam, color: col.fondo, letterSpacing: -1, whiteSpace: 'nowrap'}}>{txt}</span>
      </div>,
    );
  }
  if (estilo === 'cine') {
    const tam = ajustar(g.texto, 74, 400, 900, alto - 50, 1, fam);
    const a = suave(f, 2, 22);
    return caja(
      <div style={{textAlign: 'center'}}>
        <div style={{fontFamily: fam, fontWeight: 400, fontSize: tam, color: col.texto, opacity: a, letterSpacing: interpolate(a, [0, 1], [14, 1]),
          filter: `blur(${(1 - a) * 8}px)`, textShadow: '0 4px 24px rgba(0,0,0,.8)', whiteSpace: 'nowrap'}}>{g.texto}</div>
        <div style={{height: 3, margin: '14px auto 0', width: `${suave(f, 12, 34) * 62}%`, background: col.acento}} />
      </div>,
    );
  }
  if (estilo === 'premium') {
    const txt = g.texto.toUpperCase();
    const tam = ajustar(txt, 54, 300, 860, alto - 60, 9, fam);
    const a = suave(f, 3, 24);
    const l = suave(f, 0, 26);
    return caja(
      <div style={{textAlign: 'center', opacity: a}}>
        <div style={{height: 1.5, width: 320 * l, background: col.acento, margin: '0 auto 22px'}} />
        <div style={{fontFamily: fam, fontWeight: 300, fontSize: tam, letterSpacing: 9, color: col.texto, whiteSpace: 'nowrap', textShadow: '0 2px 16px rgba(0,0,0,.6)'}}>{txt}</div>
        <div style={{height: 1.5, width: 320 * l, background: col.acento, margin: '22px auto 0'}} />
      </div>,
    );
  }
  // panel (explicador): el titulo entra completo, la ultima palabra en el color de acento
  const pal = g.texto.split(' ');
  const tam = ajustar(g.texto, 92, 900, 1800, (alto - 20) / 2, -1, fam);
  const s = entrada(f, fps, 1, {damping: 13, stiffness: 200});
  return caja(
    <div style={{display: 'flex', flexWrap: 'wrap', justifyContent: 'center', gap: `0 ${tam * 0.28}px`, maxWidth: 940,
      transform: `translateY(${interpolate(s, [0, 1], [40, 0])}px) scale(${interpolate(s, [0, 1], [0.85, 1])})`, opacity: s}}>
      {pal.map((w: string, i: number) => (
        <span key={i} style={{fontFamily: fam, fontWeight: 900, fontSize: tam, lineHeight: 1.05, color: i === pal.length - 1 ? col.acento : col.texto, display: 'inline-block'}}>{w}</span>
      ))}
    </div>,
    {alignItems: 'center'},
  );
};

// ---------- Barra de progreso ----------
export const Barra: React.FC<{p: Props}> = ({p}) => {
  const f = useCurrentFrame();
  const col = colores(p);
  const b = p.receta.barra;
  if (!b || !b.alto) return null;
  const top = p.receta.look?.franjas ? p.receta.look.franjas - b.alto : 0;
  const c = b.color === 'texto' ? col.texto : b.color === 'fondo' ? col.fondo : col.acento;
  return (
    <div style={{position: 'absolute', top: Math.max(0, top), left: 0, height: b.alto, width: `${(f / (p.duracion - 1)) * 100}%`, background: c, opacity: b.opacidad ?? 1,
      borderRadius: b.alto > 6 ? `0 ${b.alto}px ${b.alto}px 0` : 0}} />
  );
};

// ---------- Titulos de capitulo (premium) ----------
export const Capitulos: React.FC<{p: Props}> = ({p}) => {
  const f = useCurrentFrame();
  const {fps} = useVideoConfig();
  const col = colores(p);
  const fam = familia(p);
  if (!p.receta.capitulos) return null;
  const t = f / fps;
  const c = p.capitulos.find((x: any) => t >= x.desde && t < x.desde + 1.9);
  if (!c) return null;
  const e = f - Math.round(c.desde * fps);
  const a = suave(e, 0, 12) * interpolate(e, [48, 57], [1, 0], clamp);
  const [z0, z1] = c.zona;
  const txt = c.texto.toUpperCase();
  const tam = ajustar(txt, 50, 400, 860, 70, 10, fam);
  return (
    <div style={{position: 'absolute', left: 0, right: 0, top: z0, height: Math.max(120, z1 - z0), display: 'flex', alignItems: 'center', justifyContent: 'center', opacity: a}}>
      <div style={{textAlign: 'center'}}>
        <div style={{fontFamily: fam, fontWeight: 700, fontSize: 34, letterSpacing: 8, color: col.acento, textShadow: '0 2px 10px rgba(0,0,0,.6)'}}>{String(c.num).padStart(2, '0')}</div>
        <div style={{width: 60 * suave(e, 4, 20), height: 1.5, background: col.acento, margin: '12px auto'}} />
        <div style={{fontFamily: fam, fontWeight: 400, fontSize: tam, letterSpacing: 10, color: col.texto, textShadow: '0 2px 8px rgba(0,0,0,.9), 0 0 30px rgba(0,0,0,.5)', whiteSpace: 'nowrap'}}>{txt}</div>
      </div>
    </div>
  );
};

// ---------- Barra de nombre ----------
export const Nombre: React.FC<{p: Props}> = ({p}) => {
  const f = useCurrentFrame();
  const {fps} = useVideoConfig();
  const col = colores(p);
  const fam = familia(p);
  const n = p.receta.barra_nombre;
  if (!n?.mostrar || !p.nombreZona || !p.marca?.nombre) return null;
  const a0 = Math.round(p.nombreDesde * fps), a1 = a0 + Math.round(n.segundos * fps);
  if (f < a0 || f > a1) return null;
  const e = f - a0;
  const ent = suave(e, 0, 14), sal = interpolate(f, [a1 - 10, a1], [1, 0], clamp);
  const [z0, z1] = p.nombreZona;
  return (
    <div style={{position: 'absolute', left: 70, top: (z0 + z1) / 2 - 55, height: 110, display: 'flex', alignItems: 'center', opacity: sal}}>
      <div style={{width: 4, height: 120 * ent, background: col.acento, marginRight: 22}} />
      <div style={{transform: `translateX(${(1 - ent) * -30}px)`, opacity: ent}}>
        <div style={{fontFamily: fam, fontWeight: 600, fontSize: 52, letterSpacing: 2, color: col.texto, textShadow: '0 2px 12px rgba(0,0,0,.7)'}}>{p.marca.nombre}</div>
        {p.marca.cargo && <div style={{fontFamily: fam, fontWeight: 400, fontSize: 32, letterSpacing: 5, color: col.texto, opacity: 0.9, textTransform: 'uppercase', marginTop: 4, textShadow: '0 2px 12px rgba(0,0,0,.7)'}}>{p.marca.cargo}</div>}
      </div>
    </div>
  );
};

// ---------- Llamado a la accion final ----------
export const Cta: React.FC<{p: Props}> = ({p}) => {
  const f = useCurrentFrame();
  const {fps} = useVideoConfig();
  const col = colores(p);
  const fam = familia(p);
  const st = Math.round(p.cta.desde * fps);
  if (f < st || !p.cta.texto) return null;
  const e = f - st;
  const {antes, clave, despues} = partirCta(p.cta.texto, p.cta.resaltar);
  const estilo = p.receta.cta.estilo;
  const firma = p.logo ? <Img src={staticFile(p.logo)} style={{height: 70, marginTop: 40, opacity: suave(e, 14, 26)}} /> : (
    <div style={{fontFamily: fam, fontWeight: 600, fontSize: 28, letterSpacing: 6, color: col.texto, opacity: 0.75 * suave(e, 14, 26), marginTop: 46, textTransform: 'uppercase'}}>{p.marca?.nombre}</div>
  );
  const fondo = (op: number) => <div style={{position: 'absolute', inset: 0, background: col.fondo, opacity: op}} />;

  if (estilo === 'golpe') {
    const s1 = entrada(e, fps, 0, {damping: 11, stiffness: 220});
    const s2 = entrada(e, fps, 5, {damping: 8, stiffness: 260, mass: 0.6});
    const s3 = entrada(e, fps, 10, {damping: 13, stiffness: 200});
    const pulso = 1 + 0.035 * Math.sin(Math.max(0, e - 18) / 3.2);
    const t1 = antes.toUpperCase(), t3 = despues.toUpperCase();
    return (
      <>
        {fondo(interpolate(e, [0, 8], [0, 0.82], clamp))}
        <div style={{position: 'absolute', inset: 0, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center'}}>
          <div style={{fontFamily: fam, fontWeight: 900, fontSize: ajustar(t1, 110, 900, 900, 140, -1, fam), color: col.texto, transform: `scale(${s1})`, letterSpacing: -1}}>{t1}</div>
          {clave && <div style={{background: col.acento, borderRadius: 22, padding: '10px 44px', margin: '18px 0', transform: `scale(${s2 * pulso}) rotate(-3deg)`, boxShadow: '0 16px 40px rgba(0,0,0,.5)'}}>
            <span style={{fontFamily: fam, fontWeight: 900, fontSize: ajustar(clave, 130, 900, 820, 160, -2, fam), color: col.fondo, letterSpacing: -2}}>{clave}</span></div>}
          <div style={{fontFamily: fam, fontWeight: 800, fontSize: ajustar(t3, 64, 800, 900, 90, 0, fam), color: col.texto, transform: `translateY(${(1 - s3) * 40}px)`, opacity: s3}}>{t3}</div>
          {firma}
        </div>
      </>
    );
  }
  if (estilo === 'elegante') {
    const a = suave(e, 0, 10), b = suave(e, 5, 16), c = suave(e, 9, 20);
    return (
      <>
        {fondo(interpolate(e, [0, 10], [0, 0.7], clamp))}
        <div style={{position: 'absolute', inset: 0, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', textAlign: 'center'}}>
          <div style={{fontFamily: fam, fontWeight: 300, fontSize: 70, color: col.texto, opacity: a, filter: `blur(${(1 - a) * 6}px)`}}>{antes}</div>
          {clave && <div style={{fontFamily: fam, fontWeight: 700, fontSize: ajustar(clave, 104, 700, 900, 130, 14, fam), letterSpacing: 14, color: col.acento, opacity: b, margin: '16px 0 6px', filter: `blur(${(1 - b) * 6}px)`}}>{clave}</div>}
          <div style={{height: 2, width: 420 * b, background: col.acento, opacity: 0.8}} />
          <div style={{fontFamily: fam, fontWeight: 300, fontSize: 50, color: col.texto, opacity: c, marginTop: 22}}>{despues}</div>
          {firma}
        </div>
      </>
    );
  }
  if (estilo === 'premium') {
    const a = suave(e, 0, 10), b = suave(e, 6, 18);
    const per = 2 * (760 + 560);
    return (
      <>
        {fondo(interpolate(e, [0, 16], [0, 0.72], clamp))}
        <svg width={1080} height={1920} style={{position: 'absolute', inset: 0}}>
          <rect x={160} y={680} width={760} height={560} fill="none" stroke={col.acento} strokeWidth={1.5} strokeDasharray={per} strokeDashoffset={per * (1 - suave(e, 0, 22))} />
        </svg>
        <div style={{position: 'absolute', inset: 0, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', textAlign: 'center'}}>
          <div style={{fontFamily: fam, fontWeight: 300, fontSize: 40, letterSpacing: 12, color: col.texto, opacity: a, textTransform: 'uppercase'}}>{antes}</div>
          {clave && <div style={{fontFamily: fam, fontWeight: 600, fontSize: ajustar(clave, 92, 600, 640, 120, 18, fam), letterSpacing: 18, color: col.acento, opacity: b, margin: '26px 0'}}>{clave}</div>}
          <div style={{fontFamily: fam, fontWeight: 300, fontSize: 34, letterSpacing: 10, color: col.texto, opacity: b, textTransform: 'uppercase'}}>{despues}</div>
        </div>
      </>
    );
  }
  // panel (explicador): burbuja de chat dibujada con la palabra escrita letra a letra
  const s = entrada(e, fps, 0, {damping: 14, stiffness: 190});
  const letras = Math.floor(interpolate(e, [8, 8 + (clave.length || 1) * 2], [0, clave.length], clamp));
  const cursor = Math.floor(e / 8) % 2 === 0;
  return (
    <>
      {fondo(interpolate(e, [0, 8], [0, 0.9], clamp))}
      <div style={{position: 'absolute', inset: 0, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center'}}>
        <div style={{fontFamily: fam, fontWeight: 800, fontSize: 66, color: col.texto, opacity: suave(e, 0, 8)}}>{antes}</div>
        <div style={{position: 'relative', margin: '34px 0', transform: `scale(${s})`}}>
          <div style={{background: col.texto, borderRadius: 48, padding: '28px 60px', minWidth: 520, textAlign: 'center'}}>
            <span style={{fontFamily: fam, fontWeight: 900, fontSize: 104, color: col.fondo, letterSpacing: 2}}>{clave.slice(0, letras)}</span>
            <span style={{display: 'inline-block', width: 8, height: 92, background: col.acento, marginLeft: 6, opacity: cursor ? 1 : 0, verticalAlign: 'middle'}} />
          </div>
          <svg width={70} height={50} style={{position: 'absolute', left: 70, bottom: -40}}><path d="M0 0 L60 0 L10 45 Z" fill={col.texto} /></svg>
        </div>
        <div style={{fontFamily: fam, fontWeight: 800, fontSize: 56, color: col.acento, opacity: suave(e, 12, 22)}}>{despues}</div>
        {firma}
      </div>
    </>
  );
};
