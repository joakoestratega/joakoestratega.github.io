import React from 'react';
import {Composition} from 'remotion';
import {Reel} from './Reel';

export const Root: React.FC = () => (
  <Composition
    id="Reel"
    component={Reel as any}
    width={1080}
    height={1920}
    fps={30}
    durationInFrames={300}
    defaultProps={{} as any}
    calculateMetadata={({props}: any) => ({durationInFrames: Math.max(1, props.duracion || 300)})}
  />
);
