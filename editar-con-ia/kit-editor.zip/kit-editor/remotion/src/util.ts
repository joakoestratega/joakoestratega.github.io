import {Easing, interpolate, spring} from 'remotion';
import {measureText} from '@remotion/layout-utils';

export type Props = any;

export const FAMILIA = '"Montserrat Variable", Montserrat, sans-serif';

export const colores = (p: Props) => ({
  fondo: p.marca?.colores?.fondo ?? '#0F0F14',
  acento: p.marca?.colores?.acento ?? '#F8B400',
  texto: p.marca?.colores?.texto ?? '#FFFFFF',
});

export const familia = (p: Props) => (p.marca?.fuente_archivo ? `"MarcaPropia", ${FAMILIA}` : FAMILIA);

export const clamp = {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'} as const;

export const entrada = (f: number, fps: number, retraso = 0, cfg: any = {damping: 14, stiffness: 180, mass: 0.7}) =>
  spring({frame: f - retraso, fps, config: cfg});

export const suave = (f: number, a: number, b: number) =>
  interpolate(f, [a, b], [0, 1], {...clamp, easing: Easing.bezier(0.25, 0.1, 0.25, 1)});

// Escala del video en el segundo t: push-in continuo + punch-in en frases fuertes. Nunca baja de 1 (no hay bordes negros).
export const escalaEn = (p: Props, t: number, fps: number) => {
  const c = p.cortes.find((x: any) => t >= x.desde && t < x.hasta) ?? p.cortes[p.cortes.length - 1];
  const prog = (t - c.desde) / Math.max(0.01, c.hasta - c.desde);
  let s = c.s0 + (c.s1 - c.s0) * prog;
  const z = p.receta.zoom;
  for (const [a, b] of c.punch) {
    if (t < a - 0.01 || t > b + 0.4) continue;
    if (z.punch_estilo === 'corte') {
      if (t >= a && t < b) s *= z.punch;
    } else {
      const ini = spring({frame: Math.round((t - a) * fps), fps, config: {damping: 200, stiffness: 60}});
      const fin = interpolate(t, [b, b + 0.4], [1, 0], clamp);
      s *= 1 + (z.punch - 1) * ini * fin;
    }
  }
  return {c, s: Math.max(1, Math.min(s, 1.3))};
};

// Tamano de letra que cabe en el ancho y en el alto disponibles
export const ajustar = (texto: string, tam: number, peso: number, ancho: number, alto: number, espaciado = 0, fam = FAMILIA, factorAlto = 1.18) => {
  let w = 1;
  try {
    w = measureText({text: texto, fontFamily: fam, fontSize: tam, fontWeight: String(peso), letterSpacing: `${espaciado}px`}).width;
  } catch (e) {
    w = texto.length * tam * 0.62;
  }
  const porAncho = (tam * ancho) / Math.max(1, w);
  const porAlto = alto / factorAlto;
  return Math.max(tam * 0.5, Math.min(tam, porAncho, porAlto));
};

export const partirCta = (texto: string, resaltar?: string) => {
  if (!resaltar || !texto.includes(resaltar)) return {antes: texto, clave: '', despues: ''};
  const i = texto.indexOf(resaltar);
  return {antes: texto.slice(0, i).trim(), clave: resaltar, despues: texto.slice(i + resaltar.length).trim()};
};
