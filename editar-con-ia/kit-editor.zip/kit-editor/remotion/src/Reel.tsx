import React, {useEffect, useState} from 'react';
import {AbsoluteFill, OffthreadVideo, continueRender, delayRender, interpolate, staticFile, useCurrentFrame, useVideoConfig} from 'remotion';
import '@fontsource-variable/montserrat/wght.css';
import {Props, clamp, colores, escalaEn} from './util';
import {Subtitulos} from './Subtitulos';
import {Barra, Capitulos, Cta, Gancho, Nombre} from './Titulos';
import {Destacado, Tarjetas} from './Tarjetas';

const useFuentes = (p: Props) => {
  const [h] = useState(() => delayRender('fuentes'));
  useEffect(() => {
    const muestra = 'ÁÉÍÓÚáéíóúÑñ¿¡ABCabc123$';
    const cargas: Promise<any>[] = [100, 300, 400, 500, 600, 700, 800, 900].map((w) => document.fonts.load(`${w} 40px "Montserrat Variable"`, muestra));
    if (p.marca?.fuente_archivo) {
      const ff = new FontFace('MarcaPropia', `url(${staticFile(p.marca.fuente_archivo)})`);
      cargas.push(ff.load().then((x) => document.fonts.add(x)));
    }
    Promise.all(cargas).then(() => continueRender(h)).catch(() => continueRender(h));
  }, []);
};

const Video: React.FC<{p: Props}> = ({p}) => {
  const f = useCurrentFrame();
  const {fps} = useVideoConfig();
  const {c, s} = escalaEn(p, f / fps, fps);
  return (
    <AbsoluteFill style={{transform: `translateY(${c.dy}px) scale(${s})`, transformOrigin: `${c.cx}px ${c.cy}px`}}>
      <OffthreadVideo src={staticFile(p.video)} muted style={{width: 1080, height: 1920}} />
    </AbsoluteFill>
  );
};

const Acabado: React.FC<{p: Props}> = ({p}) => {
  const f = useCurrentFrame();
  const {fps} = useVideoConfig();
  const t = f / fps;
  const look = p.receta.look || {};
  const tr = p.receta.transiciones || {};
  const dur = p.duracion / fps;
  let negro = 0;
  if (tr.fundido_inicio) negro = Math.max(negro, interpolate(t, [0, tr.fundido_inicio], [1, 0], clamp));
  if (tr.fundido_final) negro = Math.max(negro, interpolate(t, [dur - tr.fundido_final, dur], [0, 1], clamp));
  let flash = 0;
  const cambios = p.cortes.filter((c: any, i: number) => i > 0 && c.seccion !== p.cortes[i - 1].seccion).map((c: any) => c.desde);
  for (const x of cambios) {
    if (tr.fundido_secciones) negro = Math.max(negro, 0.9 * interpolate(Math.abs(t - x), [0, tr.fundido_secciones], [1, 0], clamp));
    if (tr.flash) flash = Math.max(flash, interpolate(t - x, [0, 0.1], [0.45, 0], clamp) * (t >= x ? 1 : 0));
  }
  const franja = look.franjas || 0;
  const fr = interpolate(t, [0, 0.7], [0, 1], clamp);
  return (
    <>
      {look.vineta > 0 && <AbsoluteFill style={{background: `radial-gradient(ellipse 75% 62% at 50% 45%, transparent 55%, rgba(0,0,0,${look.vineta}) 100%)`}} />}
      {franja > 0 && <>
        <div style={{position: 'absolute', top: 0, left: 0, right: 0, height: franja * fr, background: '#000'}} />
        <div style={{position: 'absolute', bottom: 0, left: 0, right: 0, height: franja * fr, background: '#000'}} />
      </>}
      {flash > 0 && <AbsoluteFill style={{background: '#fff', opacity: flash}} />}
      {negro > 0 && <AbsoluteFill style={{background: '#000', opacity: negro}} />}
    </>
  );
};

const Panel: React.FC<{p: Props}> = ({p}) => {
  const col = colores(p);
  const alto = p.receta.encuadre.alto_panel;
  return (
    <div style={{position: 'absolute', top: 0, left: 0, right: 0, height: alto, background: col.fondo, overflow: 'hidden'}}>
      <svg width={1080} height={alto} style={{position: 'absolute', inset: 0, opacity: 0.18}}>
        {Array.from({length: 18}).map((_, i) => Array.from({length: 12}).map((__, j) => (
          <circle key={`${i}-${j}`} cx={30 + i * 60} cy={30 + j * 60} r={2.2} fill={col.acento} />
        )))}
      </svg>
      <div style={{position: 'absolute', bottom: 0, left: 0, right: 0, height: 8, background: col.acento}} />
    </div>
  );
};

export const Reel: React.FC<Props> = (p) => {
  useFuentes(p);
  const panel = p.receta.encuadre?.modo === 'panel';
  const alto = panel ? p.receta.encuadre.alto_panel : 0;
  const zonaPanel: [number, number] = [90, alto - 165];
  return (
    <AbsoluteFill style={{background: '#000'}}>
      <Video p={p} />
      {panel && <Panel p={p} />}
      {panel && <Tarjetas p={p} zona={zonaPanel} />}
      {panel && <Destacado p={p} zona={zonaPanel} />}
      <Acabado p={p} />
      <Capitulos p={p} />
      <Nombre p={p} />
      <Gancho p={p} />
      <Subtitulos p={p} />
      <Cta p={p} />
      <Barra p={p} />
    </AbsoluteFill>
  );
};
