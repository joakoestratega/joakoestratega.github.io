import React from 'react';
import {interpolate, useCurrentFrame, useVideoConfig} from 'remotion';
import {Props, ajustar, clamp, colores, entrada, familia} from './util';

// Una pantalla = una frase corta completa (la arma kit/base.py). Palabra activa resaltada.
export const Subtitulos: React.FC<{p: Props}> = ({p}) => {
  const f = useCurrentFrame();
  const {fps} = useVideoConfig();
  const t = f / fps;
  const sub = p.receta.subtitulos;
  const col = colores(p);
  const fam = familia(p);
  if (t >= p.cta.desde) return null;
  const g = p.grupos.find((x: any) => t >= x.desde && t < x.hasta);
  if (!g) return null;
  const f0 = Math.round(g.desde * fps);
  const edad = f - f0;
  const may = (s: string) => (sub.mayusculas ? s.toUpperCase() : s);
  const lineas: number[][] = g.lineas || [g.palabras.map((_: any, i: number) => i)];
  const ancho = (sub.caja ? 900 : 960) * (sub.estilo === 'creador' ? 0.86 : 0.97);
  // Tamano fijo de la receta. Solo baja si una linea no cabe a lo ancho (kit/revisar.py lo marca como ANCHO).
  const tam = Math.min(...lineas.map((ln) => ajustar(ln.map((k) => may(g.palabras[k].t)).join(' '), g.tam || sub.tam, sub.peso, ancho, 9999, sub.espaciado, fam)));
  const idx = p.grupos.indexOf(g);
  const pegado = idx + 1 < p.grupos.length && p.grupos[idx + 1].desde - g.hasta < 0.05;
  const salida = pegado ? 1 : interpolate(t, [g.hasta - 0.1, g.hasta], [1, 0], clamp);

  let caja: React.CSSProperties = {};
  let mov = '';
  let op = 1;
  let filtro = '';
  if (sub.animacion === 'pop') {
    const s = entrada(edad, fps, 0, {damping: 12, stiffness: 260, mass: 0.6});
    mov = `scale(${interpolate(s, [0, 1], [0.72, 1])})`;
  } else if (sub.animacion === 'fundido') {
    op = interpolate(edad, [0, 4], [0.15, 1], clamp) * salida;
    filtro = `blur(${interpolate(edad, [0, 4], [4, 0], clamp)}px)`;
    mov = `translateY(${interpolate(edad, [0, 6], [8, 0], clamp)}px)`;
  } else if (sub.animacion === 'subir') {
    const s = entrada(edad, fps, 0, {damping: 18, stiffness: 200});
    mov = `translateY(${interpolate(s, [0, 1], [24, 0])}px)`;
    op = interpolate(edad, [0, 4], [0, 1], clamp);
  }
  if (sub.caja) {
    caja = {background: `${col.fondo}E6`, borderRadius: 22, padding: '12px 30px', border: `2px solid ${col.acento}55`};
  }

  // Fondo para que se lea siempre: cine = caja suave difuminada, premium = banda fina a lo ancho
  if (sub.fondo === 'caja_suave') {
    caja = {background: 'rgba(8,8,12,.46)', borderRadius: tam * 0.35, padding: `${tam * 0.12}px ${tam * 0.4}px`, boxShadow: '0 0 40px 18px rgba(8,8,12,.32)'};
  }
  const banda = sub.fondo === 'banda';
  const alto = lineas.length * tam * 1.15;
  return (
    <div style={{position: 'absolute', left: 0, right: 0, top: g.y - 300, height: 600, display: 'flex', alignItems: 'center', justifyContent: 'center'}}>
      {banda && <div style={{position: 'absolute', left: 0, right: 0, top: 300 - alto / 2 - tam * 0.45, height: alto + tam * 0.9, opacity: op,
        background: 'linear-gradient(90deg, rgba(15,15,20,0) 0%, rgba(15,15,20,.58) 18%, rgba(15,15,20,.58) 82%, rgba(15,15,20,0) 100%)'}} />}
      <div style={{...caja, display: 'flex', flexDirection: 'column', alignItems: 'center', transform: mov, opacity: op, filter: filtro}}>
        {lineas.map((ln, li) => (
          <div key={li} style={{display: 'flex', flexWrap: 'nowrap', justifyContent: 'center'}}>
            {ln.map((i) => {
              const w = g.palabras[i];
              const activa = t >= w.desde && (t < w.hasta + 0.05 || i === g.palabras.length - 1);
              const dicha = t >= w.desde;
              return <Palabra key={i} w={w} texto={may(w.t)} activa={activa} dicha={dicha} tam={tam} p={p} f={f} fps={fps} ultima={i === ln[ln.length - 1]} />;
            })}
          </div>
        ))}
      </div>
    </div>
  );
};

const Palabra: React.FC<any> = ({w, texto, activa, dicha, tam, p, f, fps, ultima}) => {
  const sub = p.receta.subtitulos;
  const col = colores(p);
  const fam = familia(p);
  const base: React.CSSProperties = {
    fontFamily: fam, fontWeight: sub.peso, fontSize: tam, lineHeight: 1.12, letterSpacing: sub.espaciado,
    marginRight: ultima ? 0 : tam * (sub.estilo === 'creador' ? 0.6 : 0.26), display: 'inline-block', position: 'relative', whiteSpace: 'nowrap', isolation: 'isolate',
  };
  const edadW = f - Math.round(w.desde * fps);
  if (sub.estilo === 'creador') {
    const s = activa ? entrada(edadW, fps, 0, {damping: 10, stiffness: 300, mass: 0.5}) : 1;
    const resalta = activa;
    return (
      <span style={{...base, color: resalta ? col.fondo : w.clave ? col.acento : col.texto,
        transform: `scale(${activa ? interpolate(s, [0, 1], [0.9, 1.04]) : 1}) rotate(${activa && w.clave ? -2 : 0}deg)`,
        WebkitTextStroke: resalta ? '0px' : `${sub.borde}px ${col.fondo}`, paintOrder: 'stroke fill',
        textShadow: resalta ? 'none' : '0 6px 18px rgba(0,0,0,.55)'}}>
        {resalta && <span style={{position: 'absolute', inset: `${tam * 0.0}px -${tam * 0.09}px`, background: col.acento, borderRadius: tam * 0.16, zIndex: -1, boxShadow: '0 8px 22px rgba(0,0,0,.4)'}} />}
        {texto}
      </span>
    );
  }
  if (sub.estilo === 'fino') {
    return (
      <span style={{...base, color: w.clave ? col.acento : col.texto, opacity: activa ? 1 : dicha ? 0.9 : 0.78,
        fontStyle: w.clave ? 'italic' : 'normal', textShadow: '0 2px 6px rgba(0,0,0,.95), 0 0 30px rgba(0,0,0,.7)'}}>
        {texto}
      </span>
    );
  }
  if (sub.estilo === 'premium') {
    const linea = w.clave ? interpolate(edadW, [0, 10], [0, 1], clamp) : 0;
    return (
      <span style={{...base, color: col.texto, textShadow: '0 1px 3px rgba(0,0,0,1), 0 2px 10px rgba(0,0,0,.85), 0 0 30px rgba(0,0,0,.6)'}}>
        {texto}
        {w.clave && <span style={{position: 'absolute', left: 0, bottom: -tam * 0.18, height: 3, width: `${linea * 100}%`, background: col.acento}} />}
      </span>
    );
  }
  // explicador
  const barra = activa ? interpolate(edadW, [0, 5], [0, 1], clamp) : dicha ? 1 : 0;
  return (
    <span style={{...base, color: w.clave ? col.acento : col.texto, opacity: dicha ? 1 : 0.55}}>
      {texto}
      <span style={{position: 'absolute', left: 0, bottom: -6, height: 6, borderRadius: 3, width: `${barra * 100}%`, background: activa ? col.acento : 'transparent'}} />
    </span>
  );
};
